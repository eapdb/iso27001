from flask import Flask
from config import Config
from models import db
from routes.main import main_bp
from routes.assets import assets_bp
from routes.risk_assessment import risk_assessment_bp
from routes.risk_treatment import risk_treatment_bp
from routes.settings import settings_bp
from routes.reports import reports_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    app.register_blueprint(main_bp)
    app.register_blueprint(assets_bp, url_prefix='/assets')
    app.register_blueprint(risk_assessment_bp, url_prefix='/risk_assessment')
    app.register_blueprint(risk_treatment_bp, url_prefix='/risk_treatment')
    app.register_blueprint(settings_bp, url_prefix='/settings')
    app.register_blueprint(reports_bp, url_prefix='/reports')

    return app

if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)