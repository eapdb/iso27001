from datetime import datetime
from flask import Blueprint, render_template
from models import db, Asset, RiskAssessment, RiskTreatment, AssetCategory, ThreatType ,Vulnerabilities,ControlMeasure,SystemConfig

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    total_assets = Asset.query.count()
    total_risks = RiskAssessment.query.count()
    high_risks = RiskAssessment.query.filter(RiskAssessment.risk_level.in_(['高', '極高'])).count()
    total_treatments = RiskTreatment.query.count()

    # Risk distribution
    from sqlalchemy import func
    dist = db.session.query(
        RiskAssessment.risk_level,
        func.count(RiskAssessment.id).label('count')
    ).group_by(RiskAssessment.risk_level).all()

    order_map = {'極低': 0, '低': 1, '中': 2, '高': 3, '極高': 4}
    risk_distribution = sorted(dist, key=lambda x: order_map.get(x[0], 99))

    # Assets with risk count
    assets = db.session.query(
        Asset,
        AssetCategory.category_name,
        func.count(RiskAssessment.id).label('risk_count'),
        func.sum(
            db.case((RiskAssessment.risk_level.in_(['高', '極高']), 1), else_=0)
        ).label('high_risk_count')
    ).outerjoin(AssetCategory).outerjoin(RiskAssessment)\
     .group_by(Asset.id).order_by(Asset.asset_code).all()

    # Recent risk assessments
    risk_assessments = db.session.query(
        RiskAssessment, Asset.asset_name, Asset.asset_code,
        AssetCategory.category_name, ThreatType.threat_name, Vulnerabilities.vulnerability_name
    ).select_from(RiskAssessment).join(Asset).outerjoin(AssetCategory).join(ThreatType).outerjoin(Vulnerabilities)\
     .order_by(RiskAssessment.risk_score.desc(), RiskAssessment.created_at.desc()).limit(20)
    # Treatments
    treatments = db.session.query(
        RiskTreatment,
        RiskAssessment.assessment_code,
        RiskAssessment.risk_level,
        RiskAssessment.risk_score,
        Asset.asset_name,
        ControlMeasure.control_name,
        ControlMeasure.implementation_cost,
        ControlMeasure.annual_cost
    ).join(RiskAssessment).join(Asset).outerjoin(ControlMeasure)\
     .order_by(RiskTreatment.created_at.desc()).limit(20)

    company_name = db.session.query(SystemConfig.config_value)\
        .filter_by(config_key='company_name').scalar() or '未設定組織'

    return render_template('index.html',
                           total_assets=total_assets,
                           total_risks=total_risks,
                           high_risks=high_risks,
                           total_treatments=total_treatments,
                           risk_distribution=risk_distribution,
                           assets=assets,
                           risk_assessments=risk_assessments,
                           treatments=treatments,
                           company_name=company_name,now=datetime.now)