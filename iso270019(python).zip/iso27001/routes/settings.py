from flask import Blueprint, request, redirect, url_for, flash, render_template
from models import db, SystemConfig, AssetCategory, ThreatType, Vulnerabilities, ControlMeasure

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/', methods=['GET', 'POST'])
def settings():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_config':
            for key, value in request.form.items():
                if key.startswith('config_'):
                    config_key = key.replace('config_', '')
                    config = SystemConfig.query.filter_by(config_key=config_key).first()
                    if config:
                        config.config_value = value
            db.session.commit()
            flash('系統設定已更新', 'success')
        elif action == 'add_category':
            cat = AssetCategory(
                category_name=request.form['category_name'],
                category_desc=request.form.get('category_desc', ''),
                display_order=int(request.form.get('display_order', 0))
            )
            db.session.add(cat)
            db.session.commit()
            flash('資產類別已新增', 'success')
        elif action == 'add_threat':
            threat = ThreatType(
                threat_name=request.form['threat_name'],
                threat_desc=request.form.get('threat_desc', ''),
                threat_category=request.form['threat_category'],
                display_order=int(request.form.get('display_order', 0))
            )
            db.session.add(threat)
            db.session.commit()
            flash('威脅類型已新增', 'success')
        elif action == 'add_vulnerability':
            vuln = Vulnerabilities(
                vulnerability_name=request.form['vulnerability_name'],
                vulnerability_desc=request.form.get('vulnerability_desc', ''),
                vulnerability_type=request.form['vulnerability_type'],
                ease_of_exploitation=int(request.form['ease_of_exploitation'])
            )
            db.session.add(vuln)
            db.session.commit()
            flash('漏洞已新增', 'success')
        elif action == 'add_control':
            ctrl = ControlMeasure(
                control_code=f"CTRL{ControlMeasure.query.count() + 1:04d}",
                control_name=request.form['control_name'],
                control_desc=request.form.get('control_desc', ''),
                control_type=request.form['control_type'],
                iso_annex_ref=request.form.get('iso_annex_ref', ''),
                implementation_cost=float(request.form.get('implementation_cost', 0)),
                annual_cost=float(request.form.get('annual_cost', 0)),
                effectiveness=int(request.form['effectiveness'])
            )
            db.session.add(ctrl)
            db.session.commit()
            flash('控制措施已新增', 'success')
        elif action == 'edit_category':
            cat = AssetCategory.query.get(request.form['category_id'])
            if cat:
                cat.category_name = request.form['category_name']
                cat.category_desc = request.form.get('category_desc', '')
                cat.display_order = int(request.form.get('display_order', 0))
                cat.is_active = request.form.get('is_active') == 'on'
                db.session.commit()
                flash('資產類別已更新', 'success')
        elif action == 'delete_category':
            cat = AssetCategory.query.get(request.form['category_id'])
            if cat:
                db.session.delete(cat)
                db.session.commit()
                flash('資產類別已刪除', 'success')
        elif action == 'edit_threat':
            threat = ThreatType.query.get(request.form['threat_id'])
            if threat:
                threat.threat_name = request.form['threat_name']
                threat.threat_desc = request.form.get('threat_desc', '')
                threat.threat_category = request.form['threat_category']
                threat.display_order = int(request.form.get('display_order', 0))
                threat.is_active = request.form.get('is_active') == 'on'
                db.session.commit()
                flash('威脅類型已更新', 'success')
        elif action == 'delete_threat':
            threat = ThreatType.query.get(request.form['threat_id'])
            if threat:
                db.session.delete(threat)
                db.session.commit()
                flash('威脅類型已刪除', 'success')
        elif action == 'edit_vulnerability':
            vuln = Vulnerabilities.query.get(request.form['vulnerability_id'])
            if vuln:
                vuln.vulnerability_name = request.form['vulnerability_name']
                vuln.vulnerability_desc = request.form.get('vulnerability_desc', '')
                vuln.vulnerability_type = request.form['vulnerability_type']
                vuln.ease_of_exploitation = int(request.form['ease_of_exploitation'])
                vuln.is_active = request.form.get('is_active') == 'on'
                db.session.commit()
                flash('漏洞已更新', 'success')
        elif action == 'delete_vulnerability':
            vuln = Vulnerabilities.query.get(request.form['vulnerability_id'])
            if vuln:
                db.session.delete(vuln)
                db.session.commit()
                flash('漏洞已刪除', 'success')
        elif action == 'edit_control':
            ctrl = ControlMeasure.query.get(request.form['control_id'])
            if ctrl:
                ctrl.control_name = request.form['control_name']
                ctrl.control_desc = request.form.get('control_desc', '')
                ctrl.control_type = request.form['control_type']
                ctrl.iso_annex_ref = request.form.get('iso_annex_ref', '')
                ctrl.implementation_cost = float(request.form.get('implementation_cost', 0))
                ctrl.annual_cost = float(request.form.get('annual_cost', 0))
                ctrl.effectiveness = int(request.form['effectiveness'])
                ctrl.is_active = request.form.get('is_active') == 'on'
                db.session.commit()
                flash('控制措施已更新', 'success')
        elif action == 'delete_control':
            ctrl = ControlMeasure.query.get(request.form['control_id'])
            if ctrl:
                db.session.delete(ctrl)
                db.session.commit()
                flash('控制措施已刪除', 'success')
        return redirect(url_for('settings.settings'))

    configs = SystemConfig.query.all()
    categories = AssetCategory.query.order_by(AssetCategory.display_order).all()
    threats = ThreatType.query.order_by(ThreatType.display_order).all()
    vulnerabilities = Vulnerabilities.query.order_by(Vulnerabilities.display_order).all()
    controls = ControlMeasure.query.order_by(ControlMeasure.id).all()

    return render_template('settings.html',
                           system_configs=configs,
                           categories=categories,
                           threats=threats,
                           vulnerabilities=vulnerabilities,
                           controls=controls)