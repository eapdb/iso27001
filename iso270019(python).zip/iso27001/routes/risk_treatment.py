# routes/risk_treatment.py
from flask import Blueprint, request, redirect, url_for, flash, render_template
from models import db, RiskTreatment, RiskAssessment, ControlMeasure, Asset
from datetime import datetime

risk_treatment_bp = Blueprint('risk_treatment', __name__)

@risk_treatment_bp.route('/')
def list_treatments():
    treatments = (
        db.session.query(
            RiskTreatment,
            RiskAssessment.assessment_code,
            RiskAssessment.risk_level,
            RiskAssessment.risk_score,
            Asset.asset_name,
            ControlMeasure.control_name,
        )
        .select_from(RiskTreatment)
        .join(RiskAssessment, RiskTreatment.risk_assessment)
        .join(Asset, RiskAssessment.asset)
        .outerjoin(ControlMeasure, RiskTreatment.control_measure)
        .all()
    )
    return render_template('risk_treatment/list.html', treatments=treatments)

@risk_treatment_bp.route('/add', methods=['GET', 'POST'])
def add_treatment():
    if request.method == 'POST':
        treatment = RiskTreatment(
            risk_assessment_id=request.form['risk_assessment_id'],
            treatment_strategy=request.form['treatment_strategy'],
            control_measure_id=request.form.get('control_measure_id') or None,
            residual_risk_level=request.form.get('residual_risk_level', ''),
            residual_risk_score=float(request.form.get('residual_risk_score', 0)),
            implementation_priority=request.form['implementation_priority'],
            responsible_person=request.form['responsible_person'],
            target_date=datetime.datetime.strptime(request.form['target_date'], '%Y-%m-%d').date(),
            status=request.form['status'],
            cost_benefit_ratio=float(request.form.get('cost_benefit_ratio', 0)),
            notes=request.form.get('notes', '')
        )
        db.session.add(treatment)
        try:
            db.session.commit()
            flash('風險處理計畫已新增', 'success')
            return redirect(url_for('risk_treatment.list_treatments'))
        except Exception as e:
            db.session.rollback()
            flash(f'新增失敗：{str(e)}', 'danger')

    assessments = RiskAssessment.query.order_by(RiskAssessment.assessment_code).all()
    controls = ControlMeasure.query.filter_by(is_active=True).all()
    return render_template('risk_treatment/form.html', treatment=None, assessments=assessments, controls=controls, title='新增風險處理',now=datetime.now)

@risk_treatment_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_treatment(id):
    treatment = RiskTreatment.query.get_or_404(id)
    if request.method == 'POST':
        treatment.risk_assessment_id = request.form['risk_assessment_id']
        treatment.treatment_strategy = request.form['treatment_strategy']
        treatment.control_measure_id = request.form.get('control_measure_id') or None
        treatment.residual_risk_level = request.form.get('residual_risk_level', '')
        treatment.residual_risk_score = float(request.form.get('residual_risk_score', 0))
        treatment.implementation_priority = request.form['implementation_priority']
        treatment.responsible_person = request.form['responsible_person']
        treatment.target_date = datetime.datetime.strptime(request.form['target_date'], '%Y-%m-%d').date()
        treatment.status = request.form['status']
        treatment.cost_benefit_ratio = float(request.form.get('cost_benefit_ratio', 0))
        treatment.notes = request.form.get('notes', '')
        try:
            db.session.commit()
            flash('風險處理計畫已更新', 'success')
            return redirect(url_for('risk_treatment.list_treatments'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失敗：{str(e)}', 'danger')

    assessments = RiskAssessment.query.order_by(RiskAssessment.assessment_code).all()
    controls = ControlMeasure.query.filter_by(is_active=True).all()
    return render_template('risk_treatment/form.html', treatment=treatment, assessments=assessments, controls=controls, title='編輯風險處理')

@risk_treatment_bp.route('/delete/<int:id>', methods=['POST'])
def delete_treatment(id):
    treatment = RiskTreatment.query.get_or_404(id)
    db.session.delete(treatment)
    db.session.commit()
    flash('風險處理計畫已刪除', 'success')
    return redirect(url_for('risk_treatment.list_treatments'))