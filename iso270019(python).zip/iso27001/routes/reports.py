# routes/reports.py
from flask import Blueprint, send_file, render_template, request
from models import db, Asset, RiskAssessment, RiskTreatment, AssetCategory,ControlMeasure
import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
import datetime

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/export')
def export_excel():
    """匯出完整資產與風險評估報表至 Excel"""
    output = io.BytesIO()
    wb = Workbook()

    # ===== 工作表 1：資產清單 =====
    ws_assets = wb.active
    ws_assets.title = "資產清單"
    headers_assets = [
        "資產編號", "資產名稱", "類別", "負責人", "位置",
        "機密性(C)", "完整性(I)", "可用性(A)", "業務價值(BV)",
        "描述"
    ]
    ws_assets.append(headers_assets)
    for cell in ws_assets[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="CCCCCC")
        cell.alignment = Alignment(horizontal="center")

    assets = Asset.query.join(AssetCategory).order_by(Asset.asset_code).all()
    for asset in assets:
        ws_assets.append([
            asset.asset_code,
            asset.asset_name,
            asset.category.category_name if asset.category else "",
            asset.owner or "",
            asset.location or "",
            asset.confidentiality_value,
            asset.integrity_value,
            asset.availability_value,
            asset.business_value,
            asset.description or ""
        ])

    # ===== 工作表 2：風險評估 =====
    ws_risks = wb.create_sheet(title="風險評估")
    headers_risks = [
        "評估編號", "資產編號", "資產名稱", "威脅", "漏洞",
        "威脅可能性", "漏洞嚴重度", "影響(C/I/A)", "財務影響(萬元)",
        "風險分數", "風險等級", "評估日期", "評估人", "狀態", "備註"
    ]
    ws_risks.append(headers_risks)
    for cell in ws_risks[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="DDDDDD")
        cell.alignment = Alignment(horizontal="center")

    risks = (
        db.session.query(RiskAssessment, Asset.asset_code, Asset.asset_name)
        .select_from(RiskAssessment)
        .join(Asset, RiskAssessment.asset)
        .all()
    )
    for ra, asset_code, asset_name in risks:
        impact = f"{ra.impact_confidentiality}/{ra.impact_integrity}/{ra.impact_availability}"
        ws_risks.append([
            ra.assessment_code,
            asset_code,
            asset_name,
            ra.threat.threat_name if ra.threat else "",
            ra.vulnerability.vulnerability_name if ra.vulnerability else "",
            ra.threat_likelihood,
            ra.vulnerability_severity,
            impact,
            ra.impact_financial,
            ra.risk_score,
            ra.risk_level,
            (ra.assessment_date.strftime('%Y-%m-%d') if ra.assessment_date else ""),
            ra.assessor,
            ra.status,
            ra.notes or ""
        ])

    # ===== 工作表 3：風險處理計畫 =====
    ws_treatments = wb.create_sheet(title="風險處理計畫")
    headers_treatments = [
        "評估編號", "資產名稱", "原風險等級", "處理策略", "控制措施",
        "殘餘風險等級", "殘餘風險分數", "優先順序", "負責人",
        "目標日期", "狀態", "成本效益比", "備註"
    ]
    ws_treatments.append(headers_treatments)
    for cell in ws_treatments[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="EEEEEE")
        cell.alignment = Alignment(horizontal="center")

    treatments = (
        db.session.query(
            RiskTreatment,
            RiskAssessment.assessment_code,
            Asset.asset_name,
            RiskAssessment.risk_level,
            ControlMeasure.control_name,
        )
        .select_from(RiskTreatment)
        .join(RiskAssessment, RiskTreatment.risk_assessment)
        .join(Asset, RiskAssessment.asset)
        .outerjoin(ControlMeasure, RiskTreatment.control_measure)
        .all()
    )

    for rt, code, asset_name, orig_level, ctrl_name in treatments:
        ws_treatments.append([
            code,
            asset_name,
            orig_level,
            rt.treatment_strategy,
            ctrl_name or "",
            rt.residual_risk_level,
            rt.residual_risk_score,
            rt.implementation_priority,
            rt.responsible_person,
            (rt.target_date.strftime('%Y-%m-%d') if rt.target_date else ""),
            rt.status,
            rt.cost_benefit_ratio,
            rt.notes or ""
        ])

    wb.save(output)
    output.seek(0)

    filename = f"RiskReport_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename
    )

@reports_bp.route('/')
def dashboard():
    """風險總覽儀表板"""
    # 統計數據
    total_assets = Asset.query.count()
    total_risks = RiskAssessment.query.count()
    high_risks = RiskAssessment.query.filter(RiskAssessment.risk_level.in_(['高', '極高'])).count()
    treated_risks = db.session.query(RiskTreatment).join(RiskAssessment).count()

    # 風險矩陣資料 (5x5)
    matrix = [[0 for _ in range(5)] for _ in range(5)]
    risk_list = RiskAssessment.query.all()
    for r in risk_list:
        likelihood = r.threat_likelihood  # 1-5
        severity = max(r.impact_confidentiality, r.impact_integrity, r.impact_availability)  # 1-5
        # Excel style: row = severity-1 (從上到下), col = likelihood-1 (從左到右)
        if 1 <= likelihood <= 5 and 1 <= severity <= 5:
            matrix[5 - severity][likelihood - 1] += 1  # 反轉 Y 軸，使高影響在上方

    # 風險等級分布
    risk_levels = db.session.query(
        RiskAssessment.risk_level,
        db.func.count(RiskAssessment.id)
    ).group_by(RiskAssessment.risk_level).all()
    level_order = {'極低': 1, '低': 2, '中': 3, '高': 4, '極高': 5}
    risk_levels_sorted = sorted(risk_levels, key=lambda x: level_order.get(x[0], 0))

    return render_template(
        'reports/dashboard.html',
        total_assets=total_assets,
        total_risks=total_risks,
        high_risks=high_risks,
        treated_risks=treated_risks,
        matrix=matrix,
        risk_levels=risk_levels_sorted
    )