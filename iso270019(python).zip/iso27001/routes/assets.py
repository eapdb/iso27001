# routes/assets.py
from flask import Blueprint, request, redirect, url_for, flash, render_template
from models import db, Asset, AssetCategory
import datetime

assets_bp = Blueprint('assets', __name__)

@assets_bp.route('/')
def list_assets():
    category_id = request.args.get('category_id', type=int)
    query = Asset.query.join(AssetCategory).order_by(Asset.asset_code)
    if category_id:
        query = query.filter(Asset.category_id == category_id)
    assets = query.all()
    categories = AssetCategory.query.order_by(AssetCategory.display_order).all()
    return render_template('assets/list.html', assets=assets, categories=categories, selected_category=category_id)

@assets_bp.route('/add', methods=['GET', 'POST'])
def add_asset():
    if request.method == 'POST':
        # Auto-generate asset code
        next_count = Asset.query.count() + 1
        asset_code = f"AS-{next_count:03d}"
        asset = Asset(
            asset_code=asset_code,
            asset_name=request.form['asset_name'],
            category_id=request.form['category_id'],
            description=request.form.get('description', ''),
            owner=request.form.get('owner', ''),
            location=request.form.get('location', ''),
            confidentiality_value=int(request.form.get('confidentiality_value', 1)),
            integrity_value=int(request.form.get('integrity_value', 1)),
            availability_value=int(request.form.get('availability_value', 1)),
            business_value=int(request.form.get('business_value', 1))
        )
        db.session.add(asset)
        try:
            db.session.commit()
            flash('資產已成功新增', 'success')
            return redirect(url_for('assets.list_assets'))
        except Exception as e:
            db.session.rollback()
            flash(f'新增失敗：{str(e)}', 'danger')
    
    categories = AssetCategory.query.filter_by(is_active=True).order_by(AssetCategory.display_order).all()
    return render_template('assets/form.html', asset=None, categories=categories, title='新增資產')

@assets_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_asset(id):
    asset = Asset.query.get_or_404(id)
    if request.method == 'POST':
        asset.asset_code = request.form['asset_code']
        asset.asset_name = request.form['asset_name']
        asset.category_id = request.form['category_id']
        asset.description = request.form.get('description', '')
        asset.owner = request.form.get('owner', '')
        asset.location = request.form.get('location', '')
        asset.confidentiality_value = int(request.form.get('confidentiality_value', 1))
        asset.integrity_value = int(request.form.get('integrity_value', 1))
        asset.availability_value = int(request.form.get('availability_value', 1))
        asset.business_value = int(request.form.get('business_value', 1))
        try:
            db.session.commit()
            flash('資產已更新', 'success')
            return redirect(url_for('assets.list_assets'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失敗：{str(e)}', 'danger')
    
    categories = AssetCategory.query.filter_by(is_active=True).order_by(AssetCategory.display_order).all()
    return render_template('assets/form.html', asset=asset, categories=categories, title='編輯資產')

@assets_bp.route('/delete/<int:id>', methods=['POST'])
def delete_asset(id):
    asset = Asset.query.get_or_404(id)
    # 檢查是否有風險評估關聯
    if asset.risk_assessments:
        flash('無法刪除：此資產已有風險評估紀錄', 'warning')
    else:
        db.session.delete(asset)
        db.session.commit()
        flash('資產已刪除', 'success')
    return redirect(url_for('assets.list_assets'))