# routes/risk_assessment.py
from flask import Blueprint, request, redirect, url_for, flash, render_template
from models import db, RiskAssessment, Asset, ThreatType, Vulnerabilities
from datetime import datetime

risk_assessment_bp = Blueprint('risk_assessment', __name__)

@risk_assessment_bp.route('/')
def list_risks():
    risks = db.session.query(RiskAssessment, Asset.asset_name, ThreatType.threat_name, Vulnerabilities.vulnerability_name)\
        .join(Asset).join(ThreatType).outerjoin(Vulnerabilities)\
        .order_by(RiskAssessment.risk_score.desc()).all()
    return render_template('risk_assessment/list.html', risks=risks)

@risk_assessment_bp.route('/add', methods=['GET', 'POST'])
def add_risk():
    if request.method == 'POST':
        current_year = datetime.now().year
        # Count records for current year
        current_year_count = db.session.query(RiskAssessment).filter(
            RiskAssessment.assessment_code.like(f'RA-{current_year}-%')
        ).count() + 1
        assessment_code = f"RA-{current_year}-{current_year_count:03d}"
        risk = RiskAssessment(
            assessment_code=assessment_code,
            asset_id=request.form['asset_id'],
            threat_id=request.form['threat_id'],
            vulnerability_id=request.form.get('vulnerability_id') or None,
            threat_likelihood=int(request.form['threat_likelihood']),
            vulnerability_severity=int(request.form['vulnerability_severity']),
            impact_confidentiality=int(request.form['impact_confidentiality']),
            impact_integrity=int(request.form['impact_integrity']),
            impact_availability=int(request.form['impact_availability']),
            impact_financial=float(request.form.get('impact_financial', 0)),
            assessment_date=datetime.strptime(request.form['assessment_date'], '%Y-%m-%d').date(),
            assessor=request.form['assessor'],
            notes=request.form.get('notes', '')
        )

        # 計算風險分數（簡化版）
        likelihood = risk.threat_likelihood * risk.vulnerability_severity
        impact = max(risk.impact_confidentiality, risk.impact_integrity, risk.impact_availability)
        risk.risk_score = round(likelihood * impact, 2)

        # 風險等級
        if risk.risk_score >= 16:
            risk.risk_level = '極高'
        elif risk.risk_score >= 10:
            risk.risk_level = '高'
        elif risk.risk_score >= 6:
            risk.risk_level = '中'
        elif risk.risk_score >= 3:
            risk.risk_level = '低'
        else:
            risk.risk_level = '極低'

        db.session.add(risk)
        try:
            db.session.commit()
            flash('風險評估已新增', 'success')
            return redirect(url_for('risk_assessment.list_risks'))
        except Exception as e:
            db.session.rollback()
            flash(f'新增失敗：{str(e)}', 'danger')

    assets = Asset.query.order_by(Asset.asset_code).all()
    threats = ThreatType.query.filter_by(is_active=True).order_by(ThreatType.display_order).all()
    vulnerabilities = Vulnerabilities.query.filter_by(is_active=True).order_by(Vulnerabilities.display_order).all()
    return render_template('risk_assessment/form.html', risk=None, assets=assets, threats=threats, vulnerabilities=vulnerabilities, title='新增風險評估',now=datetime.now)

@risk_assessment_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_risk(id):
    risk = RiskAssessment.query.get_or_404(id)
    if request.method == 'POST':
        risk.asset_id = request.form['asset_id']
        risk.threat_id = request.form['threat_id']
        risk.vulnerability_id = request.form.get('vulnerability_id') or None
        risk.threat_likelihood = int(request.form['threat_likelihood'])
        risk.vulnerability_severity = int(request.form['vulnerability_severity'])
        risk.impact_confidentiality = int(request.form['impact_confidentiality'])
        risk.impact_integrity = int(request.form['impact_integrity'])
        risk.impact_availability = int(request.form['impact_availability'])
        risk.impact_financial = float(request.form.get('impact_financial', 0))
        risk.assessment_date = datetime.strptime(request.form['assessment_date'], '%Y-%m-%d').date()
        risk.assessor = request.form['assessor']
        risk.notes = request.form.get('notes', '')

        # 重新計算
        likelihood = risk.threat_likelihood * risk.vulnerability_severity
        impact = max(risk.impact_confidentiality, risk.impact_integrity, risk.impact_availability)
        risk.risk_score = round(likelihood * impact, 2)

        if risk.risk_score >= 16:
            risk.risk_level = '極高'
        elif risk.risk_score >= 10:
            risk.risk_level = '高'
        elif risk.risk_score >= 6:
            risk.risk_level = '中'
        elif risk.risk_score >= 3:
            risk.risk_level = '低'
        else:
            risk.risk_level = '極低'

        try:
            db.session.commit()
            flash('風險評估已更新', 'success')
            return redirect(url_for('risk_assessment.list_risks'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失敗：{str(e)}', 'danger')

    assets = Asset.query.order_by(Asset.asset_code).all()
    threats = ThreatType.query.filter_by(is_active=True).order_by(ThreatType.display_order).all()
    vulnerabilities = Vulnerabilities.query.filter_by(is_active=True).order_by(Vulnerabilities.display_order).all()
    return render_template('risk_assessment/form.html', risk=risk, assets=assets, threats=threats, vulnerabilities=vulnerabilities, title='編輯風險評估')

@risk_assessment_bp.route('/delete/<int:id>', methods=['POST'])
def delete_risk(id):
    risk = RiskAssessment.query.get_or_404(id)
    if risk.treatments:
        flash('無法刪除：已有風險處理計畫', 'warning')
    else:
        db.session.delete(risk)
        db.session.commit()
        flash('風險評估已刪除', 'success')
    return redirect(url_for('risk_assessment.list_risks'))