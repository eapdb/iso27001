from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class SystemConfig(db.Model):
    __tablename__ = 'system_config'
    id = db.Column(db.Integer, primary_key=True)
    config_key = db.Column(db.String(100), unique=True, nullable=False)
    config_value = db.Column(db.Text)
    config_desc = db.Column(db.String(255))

class AssetCategory(db.Model):
    __tablename__ = 'asset_categories'
    id = db.Column(db.Integer, primary_key=True)
    category_name = db.Column(db.String(100), nullable=False)
    category_desc = db.Column(db.Text)
    display_order = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)

class Asset(db.Model):
    __tablename__ = 'assets'
    id = db.Column(db.Integer, primary_key=True)
    asset_code = db.Column(db.String(50), unique=True, nullable=False)
    asset_name = db.Column(db.String(200), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('asset_categories.id'))
    description = db.Column(db.Text)
    owner = db.Column(db.String(100))
    location = db.Column(db.String(200))
    confidentiality_value = db.Column(db.Integer, default=1)
    integrity_value = db.Column(db.Integer, default=1)
    availability_value = db.Column(db.Integer, default=1)
    business_value = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    category = db.relationship('AssetCategory', backref='assets')

class ThreatType(db.Model):
    __tablename__ = 'threat_types'
    id = db.Column(db.Integer, primary_key=True)
    threat_name = db.Column(db.String(200), nullable=False)
    threat_desc = db.Column(db.Text)
    threat_category = db.Column(db.String(100))
    display_order = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)

class Vulnerabilities(db.Model):
    __tablename__ = 'vulnerabilities'
    id = db.Column(db.Integer, primary_key=True)
    vulnerability_name = db.Column(db.String(200), nullable=False)
    vulnerability_desc = db.Column(db.Text)
    vulnerability_type = db.Column(db.String(100))
    ease_of_exploitation = db.Column(db.Integer, default=1)
    display_order = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)

class RiskAssessment(db.Model):
    __tablename__ = 'risk_assessments'
    id = db.Column(db.Integer, primary_key=True)
    assessment_code = db.Column(db.String(50), unique=True, nullable=False)
    asset_id = db.Column(db.Integer, db.ForeignKey('assets.id'), nullable=False)
    threat_id = db.Column(db.Integer, db.ForeignKey('threat_types.id'), nullable=False)
    vulnerability_id = db.Column(db.Integer, db.ForeignKey('vulnerabilities.id'))
    threat_likelihood = db.Column(db.Integer, default=1)
    vulnerability_severity = db.Column(db.Integer, default=1)
    impact_confidentiality = db.Column(db.Integer, default=1)
    impact_integrity = db.Column(db.Integer, default=1)
    impact_availability = db.Column(db.Integer, default=1)
    impact_financial = db.Column(db.DECIMAL(15, 2), default=0)
    risk_level = db.Column(db.String(20))
    risk_score = db.Column(db.DECIMAL(10, 2))
    assessment_date = db.Column(db.Date)
    assessor = db.Column(db.String(100))
    status = db.Column(db.String(50), default='待處理')
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    asset = db.relationship('Asset', backref='risk_assessments')
    threat = db.relationship('ThreatType', backref='risk_assessments')
    vulnerability = db.relationship('Vulnerabilities', backref='risk_assessments')

class ControlMeasure(db.Model):
    __tablename__ = 'control_measures'
    id = db.Column(db.Integer, primary_key=True)
    control_code = db.Column(db.String(50), unique=True, nullable=False)
    control_name = db.Column(db.String(200), nullable=False)
    control_desc = db.Column(db.Text)
    control_type = db.Column(db.String(100))
    iso_annex_ref = db.Column(db.String(50))
    implementation_cost = db.Column(db.DECIMAL(15, 2), default=0)
    annual_cost = db.Column(db.DECIMAL(15, 2), default=0)
    effectiveness = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)

class RiskTreatment(db.Model):
    __tablename__ = 'risk_treatments'
    id = db.Column(db.Integer, primary_key=True)
    risk_assessment_id = db.Column(db.Integer, db.ForeignKey('risk_assessments.id'), nullable=False)
    treatment_strategy = db.Column(db.String(50))
    control_measure_id = db.Column(db.Integer, db.ForeignKey('control_measures.id'))
    residual_risk_level = db.Column(db.String(20))
    residual_risk_score = db.Column(db.DECIMAL(10, 2))
    implementation_priority = db.Column(db.String(20))
    responsible_person = db.Column(db.String(100))
    target_date = db.Column(db.Date)
    status = db.Column(db.String(50), default='規劃中')
    cost_benefit_ratio = db.Column(db.DECIMAL(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    risk_assessment = db.relationship('RiskAssessment', backref='treatments')
    control_measure = db.relationship('ControlMeasure', backref='treatments')