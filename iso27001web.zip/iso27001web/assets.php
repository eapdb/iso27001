<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 資產管理界面 - 管理組織資產及其價值評估
 */
require_once 'config.php';

// 處理新增/編輯資產
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save_asset') {
        if (isset($_POST['asset_id']) && $_POST['asset_id']) {
            // 更新現有資產
            $sql = "UPDATE assets SET 
                    asset_name = ?, category_id = ?, description = ?, 
                    owner = ?, location = ?,
                    confidentiality_value = ?, integrity_value = ?, 
                    availability_value = ?, business_value = ?
                    WHERE id = ?";
            executeQuery($sql, [
                $_POST['asset_name'], $_POST['category_id'], $_POST['description'],
                $_POST['owner'], $_POST['location'],
                $_POST['confidentiality_value'], $_POST['integrity_value'],
                $_POST['availability_value'], $_POST['business_value'],
                $_POST['asset_id']
            ]);
            $message = "資產已成功更新！";
        } else {
            // 新增資產
            $asset_code = 'AS-' . str_pad(
                fetchOne("SELECT COUNT(*) + 1 as next FROM assets")['next'],
                3, '0', STR_PAD_LEFT
            );
            
            $sql = "INSERT INTO assets (
                    asset_code, asset_name, category_id, description, 
                    owner, location, confidentiality_value, integrity_value, 
                    availability_value, business_value
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            executeQuery($sql, [
                $asset_code, $_POST['asset_name'], $_POST['category_id'], 
                $_POST['description'], $_POST['owner'], $_POST['location'],
                $_POST['confidentiality_value'], $_POST['integrity_value'],
                $_POST['availability_value'], $_POST['business_value']
            ]);
            $message = "資產已成功新增！編號: {$asset_code}";
        }
    } elseif ($_POST['action'] === 'delete_asset') {
        executeQuery("DELETE FROM assets WHERE id = ?", [$_POST['asset_id']]);
        $message = "資產已刪除！";
    }
}

// 取得資產類別
$categories = fetchAll("SELECT * FROM asset_categories ORDER BY display_order");

// 取得所有資產
$assets = fetchAll("
    SELECT a.*, ac.category_name,
           (SELECT COUNT(*) FROM risk_assessments WHERE asset_id = a.id) as risk_count
    FROM assets a
    LEFT JOIN asset_categories ac ON a.category_id = ac.id
    ORDER BY a.asset_code
");

// 如果是編輯模式，取得資產資料
$edit_asset = null;
if (isset($_GET['edit_id'])) {
    $edit_asset = fetchOne("SELECT * FROM assets WHERE id = ?", [$_GET['edit_id']]);
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>資產管理 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a {
            color: white;
            text-decoration: none;
            margin-right: 1.5rem;
            font-weight: 500;
        }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
            font-size: 0.95rem;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .value-selector {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .value-btn {
            flex: 1;
            padding: 0.8rem;
            border: 2px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .value-btn:hover {
            border-color: #667eea;
            background: #f8f9fa;
        }
        
        .value-btn.selected {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .cia-badge {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 3px;
            font-size: 0.8rem;
            font-weight: bold;
            margin-right: 0.3rem;
        }
        .cia-1 { background: #d4edda; color: #155724; }
        .cia-2 { background: #d1ecf1; color: #0c5460; }
        .cia-3 { background: #fff3cd; color: #856404; }
        .cia-4 { background: #f8d7da; color: #721c24; }
        .cia-5 { background: #dc3545; color: white; }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
        }
        
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #667eea;
            margin: 1.5rem 0 1rem 0;
            padding-left: 1rem;
            border-left: 4px solid #667eea;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($message)): ?>
        <div class="alert">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- 資產表單 -->
        <div class="card">
            <h2><?php echo $edit_asset ? '✏️ 編輯資產' : '➕ 新增資產'; ?></h2>
            <div class="info-box">
                <strong>說明：</strong>資產是組織需要保護的任何有價值的項目。請評估每個資產在機密性(C)、完整性(I)、可用性(A)及業務價值方面的重要程度（1-5分）。
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="save_asset">
                <?php if ($edit_asset): ?>
                <input type="hidden" name="asset_id" value="<?php echo $edit_asset['id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>資產名稱 *</label>
                        <input type="text" name="asset_name" required 
                               value="<?php echo $edit_asset ? htmlspecialchars($edit_asset['asset_name']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>資產類別 *</label>
                        <select name="category_id" required>
                            <option value="">請選擇類別</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>"
                                <?php echo ($edit_asset && $edit_asset['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>資產負責人</label>
                        <input type="text" name="owner" 
                               value="<?php echo $edit_asset ? htmlspecialchars($edit_asset['owner']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>存放位置</label>
                        <input type="text" name="location" 
                               value="<?php echo $edit_asset ? htmlspecialchars($edit_asset['location']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group" style="margin-top: 1rem;">
                    <label>資產描述</label>
                    <textarea name="description" rows="3"><?php echo $edit_asset ? htmlspecialchars($edit_asset['description']) : ''; ?></textarea>
                </div>
                
                <div class="section-title">📊 資產價值評估 (CIA+B)</div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>機密性(Confidentiality) *</label>
                        <small style="color: #666; margin-bottom: 0.5rem;">資料被未授權存取的影響程度</small>
                        <input type="hidden" name="confidentiality_value" id="c_value" 
                               value="<?php echo $edit_asset ? $edit_asset['confidentiality_value'] : '3'; ?>">
                        <div class="value-selector" id="c_selector">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="value-btn <?php echo (!$edit_asset && $i == 3) || ($edit_asset && $edit_asset['confidentiality_value'] == $i) ? 'selected' : ''; ?>" 
                                    onclick="selectValue('c', <?php echo $i; ?>)"><?php echo $i; ?></button>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>完整性(Integrity) *</label>
                        <small style="color: #666; margin-bottom: 0.5rem;">資料被未授權修改的影響程度</small>
                        <input type="hidden" name="integrity_value" id="i_value" 
                               value="<?php echo $edit_asset ? $edit_asset['integrity_value'] : '3'; ?>">
                        <div class="value-selector" id="i_selector">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="value-btn <?php echo (!$edit_asset && $i == 3) || ($edit_asset && $edit_asset['integrity_value'] == $i) ? 'selected' : ''; ?>" 
                                    onclick="selectValue('i', <?php echo $i; ?>)"><?php echo $i; ?></button>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>可用性(Availability) *</label>
                        <small style="color: #666; margin-bottom: 0.5rem;">系統或資料無法使用的影響程度</small>
                        <input type="hidden" name="availability_value" id="a_value" 
                               value="<?php echo $edit_asset ? $edit_asset['availability_value'] : '3'; ?>">
                        <div class="value-selector" id="a_selector">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="value-btn <?php echo (!$edit_asset && $i == 3) || ($edit_asset && $edit_asset['availability_value'] == $i) ? 'selected' : ''; ?>" 
                                    onclick="selectValue('a', <?php echo $i; ?>)"><?php echo $i; ?></button>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>業務價值(Business Value) *</label>
                        <small style="color: #666; margin-bottom: 0.5rem;">對組織營運的重要程度</small>
                        <input type="hidden" name="business_value" id="b_value" 
                               value="<?php echo $edit_asset ? $edit_asset['business_value'] : '3'; ?>">
                        <div class="value-selector" id="b_selector">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="value-btn <?php echo (!$edit_asset && $i == 3) || ($edit_asset && $edit_asset['business_value'] == $i) ? 'selected' : ''; ?>" 
                                    onclick="selectValue('b', <?php echo $i; ?>)"><?php echo $i; ?></button>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
                
                <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                    <button type="submit" class="btn">💾 儲存資產</button>
                    <a href="assets.php" class="btn btn-secondary">取消</a>
                </div>
            </form>
        </div>
        
        <!-- 資產列表 -->
        <div class="card">
            <h2>📦 資產清單</h2>
            <table>
                <thead>
                    <tr>
                        <th>資產編號</th>
                        <th>資產名稱</th>
                        <th>類別</th>
                        <th>負責人</th>
                        <th>C</th>
                        <th>I</th>
                        <th>A</th>
                        <th>B</th>
                        <th>風險數</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($assets as $asset): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($asset['asset_code']); ?></strong></td>
                        <td><?php echo htmlspecialchars($asset['asset_name']); ?></td>
                        <td><?php echo htmlspecialchars($asset['category_name']); ?></td>
                        <td><?php echo htmlspecialchars($asset['owner']); ?></td>
                        <td><span class="cia-badge cia-<?php echo $asset['confidentiality_value']; ?>"><?php echo $asset['confidentiality_value']; ?></span></td>
                        <td><span class="cia-badge cia-<?php echo $asset['integrity_value']; ?>"><?php echo $asset['integrity_value']; ?></span></td>
                        <td><span class="cia-badge cia-<?php echo $asset['availability_value']; ?>"><?php echo $asset['availability_value']; ?></span></td>
                        <td><span class="cia-badge cia-<?php echo $asset['business_value']; ?>"><?php echo $asset['business_value']; ?></span></td>
                        <td><?php echo $asset['risk_count']; ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="?edit_id=<?php echo $asset['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此資產嗎？');">
                                    <input type="hidden" name="action" value="delete_asset">
                                    <input type="hidden" name="asset_id" value="<?php echo $asset['id']; ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">刪除</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        // 選擇價值按鈕
        function selectValue(type, value) {
            // 更新隱藏欄位
            document.getElementById(type + '_value').value = value;
            
            // 更新按鈕樣式
            const selector = document.getElementById(type + '_selector');
            const buttons = selector.querySelectorAll('.value-btn');
            buttons.forEach((btn, index) => {
                if (index + 1 === value) {
                    btn.classList.add('selected');
                } else {
                    btn.classList.remove('selected');
                }
            });
        }
    </script>
</body>
</html>