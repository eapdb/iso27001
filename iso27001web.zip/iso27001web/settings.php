<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 系統設定界面 - 管理可自訂的參數
 */
require_once 'config.php';

// 處理表單提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_config':
                foreach ($_POST as $key => $value) {
                    if ($key !== 'action' && strpos($key, 'config_') === 0) {
                        $config_key = substr($key, 7);
                        executeQuery(
                            "UPDATE system_config SET config_value = ? WHERE config_key = ?",
                            [$value, $config_key]
                        );
                    }
                }
                $message = "系統設定已更新！";
                break;
                
            case 'add_category':
                $sql = "INSERT INTO asset_categories (category_name, category_desc, display_order) VALUES (?, ?, ?)";
                executeQuery($sql, [$_POST['category_name'], $_POST['category_desc'], $_POST['display_order']]);
                $message = "資產類別已新增！";
                break;
                
            case 'add_threat':
                $sql = "INSERT INTO threat_types (threat_name, threat_desc, threat_category, display_order) VALUES (?, ?, ?, ?)";
                executeQuery($sql, [$_POST['threat_name'], $_POST['threat_desc'], $_POST['threat_category'], $_POST['display_order']]);
                $message = "威脅類型已新增！";
                break;
                
            case 'add_vulnerability':
                $sql = "INSERT INTO vulnerabilities (vulnerability_name, vulnerability_desc, vulnerability_type, ease_of_exploitation, display_order) VALUES (?, ?, ?, ?, ?)";
                executeQuery($sql, [$_POST['vulnerability_name'], $_POST['vulnerability_desc'], $_POST['vulnerability_type'], $_POST['ease_of_exploitation'], $_POST['display_order']]);
                $message = "漏洞已新增！";
                break;
                
            case 'add_control':
                $sql = "INSERT INTO control_measures (control_code, control_name, control_desc, control_type, iso_annex_ref, implementation_cost, annual_cost, effectiveness) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $control_code = 'CTL-' . str_pad(fetchOne("SELECT COUNT(*) + 1 as next FROM control_measures")['next'], 3, '0', STR_PAD_LEFT);
                executeQuery($sql, [
                    $control_code, $_POST['control_name'], $_POST['control_desc'], 
                    $_POST['control_type'], $_POST['iso_annex_ref'],
                    $_POST['implementation_cost'], $_POST['annual_cost'], $_POST['effectiveness']
                ]);
                $message = "控制措施已新增！編號: {$control_code}";
                break;
        }
    }
}

// 取得系統設定
$system_configs = fetchAll("SELECT * FROM system_config ORDER BY id");

// 取得各項基礎資料
$categories = fetchAll("SELECT * FROM asset_categories ORDER BY display_order");
$threats = fetchAll("SELECT * FROM threat_types ORDER BY display_order");
$vulnerabilities = fetchAll("SELECT * FROM vulnerabilities ORDER BY display_order");
$controls = fetchAll("SELECT * FROM control_measures ORDER BY control_code");
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系統設定 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a { color: white; text-decoration: none; margin-right: 1.5rem; font-weight: 500; }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #dee2e6;
            flex-wrap: wrap;
        }
        .tab {
            padding: 0.8rem 1.5rem;
            background: white;
            border: none;
            cursor: pointer;
            font-size: 0.95rem;
            border-radius: 5px 5px 0 0;
            transition: background 0.3s;
        }
        .tab.active { background: #667eea; color: white; font-weight: 600; }
        .tab:hover:not(.active) { background: #f8f9fa; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
            font-size: 0.95rem;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            font-family: inherit;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
            <a href="settings.php">系統設定</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($message)): ?>
        <div class="alert">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab(0)">⚙️ 系統參數</button>
            <button class="tab" onclick="switchTab(1)">📁 資產類別</button>
            <button class="tab" onclick="switchTab(2)">⚠️ 威脅類型</button>
            <button class="tab" onclick="switchTab(3)">🔓 漏洞管理</button>
            <button class="tab" onclick="switchTab(4)">🛡️ 控制措施</button>
        </div>
        
        <!-- Tab 0: 系統參數 -->
        <div class="tab-content active">
            <div class="card">
                <h2>⚙️ 系統參數設定</h2>
                <div class="info-box">
                    這些參數會影響風險評估的計算和顯示方式
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="update_config">
                    <div class="form-grid">
                        <?php foreach ($system_configs as $config): ?>
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($config['config_desc']); ?></label>
                            <input type="text" name="config_<?php echo $config['config_key']; ?>" 
                                   value="<?php echo htmlspecialchars($config['config_value']); ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div style="margin-top: 2rem;">
                        <button type="submit" class="btn">💾 儲存設定</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tab 1: 資產類別 -->
        <div class="tab-content">
            <div class="card">
                <h2>➕ 新增資產類別</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_category">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>類別名稱 *</label>
                            <input type="text" name="category_name" required>
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" value="0">
                        </div>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>類別說明</label>
                        <textarea name="category_desc" rows="2"></textarea>
                    </div>
                    <div style="margin-top: 1rem;">
                        <button type="submit" class="btn btn-success">新增類別</button>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有資產類別</h2>
                <table>
                    <thead>
                        <tr>
                            <th>類別名稱</th>
                            <th>說明</th>
                            <th>顯示順序</th>
                            <th>狀態</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($cat['category_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($cat['category_desc']); ?></td>
                            <td><?php echo $cat['display_order']; ?></td>
                            <td>
                                <span class="badge <?php echo $cat['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $cat['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 2: 威脅類型 -->
        <div class="tab-content">
            <div class="card">
                <h2>➕ 新增威脅類型</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_threat">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>威脅名稱 *</label>
                            <input type="text" name="threat_name" required>
                        </div>
                        <div class="form-group">
                            <label>威脅類別</label>
                            <select name="threat_category">
                                <option value="技術威脅">技術威脅</option>
                                <option value="人為威脅">人為威脅</option>
                                <option value="環境威脅">環境威脅</option>
                                <option value="外部威脅">外部威脅</option>
                                <option value="法律威脅">法律威脅</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" value="0">
                        </div>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>威脅說明</label>
                        <textarea name="threat_desc" rows="2"></textarea>
                    </div>
                    <div style="margin-top: 1rem;">
                        <button type="submit" class="btn btn-success">新增威脅</button>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有威脅類型</h2>
                <table>
                    <thead>
                        <tr>
                            <th>威脅名稱</th>
                            <th>類別</th>
                            <th>說明</th>
                            <th>狀態</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($threats as $threat): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($threat['threat_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($threat['threat_category']); ?></td>
                            <td><?php echo htmlspecialchars($threat['threat_desc']); ?></td>
                            <td>
                                <span class="badge <?php echo $threat['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $threat['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 3: 漏洞管理 -->
        <div class="tab-content">
            <div class="card">
                <h2>➕ 新增漏洞</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_vulnerability">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>漏洞名稱 *</label>
                            <input type="text" name="vulnerability_name" required>
                        </div>
                        <div class="form-group">
                            <label>漏洞類型</label>
                            <select name="vulnerability_type">
                                <option value="技術漏洞">技術漏洞</option>
                                <option value="管理漏洞">管理漏洞</option>
                                <option value="人為漏洞">人為漏洞</option>
                                <option value="實體漏洞">實體漏洞</option>
                                <option value="架構漏洞">架構漏洞</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>利用難度 (1-5)</label>
                            <select name="ease_of_exploitation">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" value="0">
                        </div>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>漏洞說明</label>
                        <textarea name="vulnerability_desc" rows="2"></textarea>
                    </div>
                    <div style="margin-top: 1rem;">
                        <button type="submit" class="btn btn-success">新增漏洞</button>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有漏洞</h2>
                <table>
                    <thead>
                        <tr>
                            <th>漏洞名稱</th>
                            <th>類型</th>
                            <th>利用難度</th>
                            <th>說明</th>
                            <th>狀態</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vulnerabilities as $vuln): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($vuln['vulnerability_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($vuln['vulnerability_type']); ?></td>
                            <td><?php echo $vuln['ease_of_exploitation']; ?>/5</td>
                            <td><?php echo htmlspecialchars($vuln['vulnerability_desc']); ?></td>
                            <td>
                                <span class="badge <?php echo $vuln['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $vuln['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 4: 控制措施 -->
        <div class="tab-content">
            <div class="card">
                <h2>➕ 新增控制措施</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_control">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>控制措施名稱 *</label>
                            <input type="text" name="control_name" required>
                        </div>
                        <div class="form-group">
                            <label>控制類型</label>
                            <select name="control_type">
                                <option value="預防性">預防性</option>
                                <option value="偵測性">偵測性</option>
                                <option value="矯正性">矯正性</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>ISO 27001 附錄A參考</label>
                            <input type="text" name="iso_annex_ref" placeholder="例如: A.8.8">
                        </div>
                        <div class="form-group">
                            <label>實施成本 (TWD)</label>
                            <input type="number" name="implementation_cost" value="0" step="0.01">
                        </div>
                        <div class="form-group">
                            <label>年度維護成本 (TWD)</label>
                            <input type="number" name="annual_cost" value="0" step="0.01">
                        </div>
                        <div class="form-group">
                            <label>有效性 (1-5)</label>
                            <select name="effectiveness">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo $i == 3 ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>控制措施說明</label>
                        <textarea name="control_desc" rows="3"></textarea>
                    </div>
                    <div style="margin-top: 1rem;">
                        <button type="submit" class="btn btn-success">新增控制措施</button>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有控制措施</h2>
                <table>
                    <thead>
                        <tr>
                            <th>編號</th>
                            <th>名稱</th>
                            <th>類型</th>
                            <th>ISO參考</th>
                            <th>實施成本</th>
                            <th>年度成本</th>
                            <th>有效性</th>
                            <th>狀態</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($controls as $control): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($control['control_code']); ?></strong></td>
                            <td><?php echo htmlspecialchars($control['control_name']); ?></td>
                            <td><?php echo htmlspecialchars($control['control_type']); ?></td>
                            <td><?php echo htmlspecialchars($control['iso_annex_ref']); ?></td>
                            <td>$<?php echo number_format($control['implementation_cost']); ?></td>
                            <td>$<?php echo number_format($control['annual_cost']); ?></td>
                            <td><?php echo $control['effectiveness']; ?>/5</td>
                            <td>
                                <span class="badge <?php echo $control['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $control['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function switchTab(index) {
            const tabs = document.querySelectorAll('.tab');
            const contents = document.querySelectorAll('.tab-content');
            
            tabs.forEach((tab, i) => {
                if (i === index) {
                    tab.classList.add('active');
                    contents[i].classList.add('active');
                } else {
                    tab.classList.remove('active');
                    contents[i].classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>