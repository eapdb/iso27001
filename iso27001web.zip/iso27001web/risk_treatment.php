<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 風險處理計畫 - 實現經濟平衡決策
 */
require_once 'config.php';

// 處理風險處理計畫提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save_treatment') {
        // 計算成本效益比
        $risk_assessment = fetchOne("SELECT * FROM risk_assessments WHERE id = ?", [$_POST['risk_assessment_id']]);
        
        $cost_benefit_ratio = 0;
        if ($_POST['treatment_strategy'] === '降低' && $_POST['control_measure_id']) {
            $control = fetchOne("SELECT * FROM control_measures WHERE id = ?", [$_POST['control_measure_id']]);
            $total_cost = $control['implementation_cost'] + ($control['annual_cost'] * 3); // 3年成本
            $risk_value = $risk_assessment['risk_score'] * 100000; // 風險價值估算
            $cost_benefit_ratio = $total_cost > 0 ? ($risk_value - $total_cost) / $total_cost : 0;
        }
        
        $sql = "INSERT INTO risk_treatments (
                risk_assessment_id, treatment_strategy, control_measure_id,
                residual_risk_level, residual_risk_score, implementation_priority,
                responsible_person, target_date, status, cost_benefit_ratio, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        executeQuery($sql, [
            $_POST['risk_assessment_id'],
            $_POST['treatment_strategy'],
            $_POST['control_measure_id'] ?: null,
            $_POST['residual_risk_level'],
            $_POST['residual_risk_score'],
            $_POST['implementation_priority'],
            $_POST['responsible_person'],
            $_POST['target_date'] ?: null,
            '規劃中',
            $cost_benefit_ratio,
            $_POST['notes']
        ]);
        
        // 更新風險評估狀態
        executeQuery("UPDATE risk_assessments SET status = '處理中' WHERE id = ?", [$_POST['risk_assessment_id']]);
        
        $message = "風險處理計畫已建立！";
    }
}

// 取得所有未處理或處理中的風險
$pending_risks = fetchAll("
    SELECT ra.*, a.asset_name, t.threat_name
    FROM risk_assessments ra
    JOIN assets a ON ra.asset_id = a.id
    JOIN threat_types t ON ra.threat_id = t.id
    WHERE ra.status IN ('待處理', '處理中')
    ORDER BY ra.risk_score DESC
");

// 取得控制措施
$control_measures = fetchAll("
    SELECT * FROM control_measures 
    WHERE is_active = 1 
    ORDER BY effectiveness DESC, implementation_cost ASC
");

// 取得所有處理計畫
$treatments = fetchAll("
    SELECT rt.*, 
           ra.assessment_code, ra.risk_level, ra.risk_score,
           a.asset_name,
           cm.control_name, cm.implementation_cost, cm.annual_cost
    FROM risk_treatments rt
    JOIN risk_assessments ra ON rt.risk_assessment_id = ra.id
    JOIN assets a ON ra.asset_id = a.id
    LEFT JOIN control_measures cm ON rt.control_measure_id = cm.id
    ORDER BY rt.created_at DESC
");

// 如果從風險評估頁面過來，取得特定風險
$selected_risk = null;
if (isset($_GET['risk_id'])) {
    $selected_risk = fetchOne("
        SELECT ra.*, a.asset_name, t.threat_name, v.vulnerability_name
        FROM risk_assessments ra
        JOIN assets a ON ra.asset_id = a.id
        JOIN threat_types t ON ra.threat_id = t.id
        LEFT JOIN vulnerabilities v ON ra.vulnerability_id = v.id
        WHERE ra.id = ?
    ", [$_GET['risk_id']]);
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>風險處理 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a { color: white; text-decoration: none; margin-right: 1.5rem; font-weight: 500; }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .risk-summary {
            background: linear-gradient(135deg, #667eea15, #764ba215);
            padding: 1.5rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            border-left: 5px solid #667eea;
        }
        
        .risk-summary h3 { margin-bottom: 1rem; color: #667eea; }
        .risk-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        .risk-summary-item strong { display: block; color: #666; font-size: 0.85rem; }
        .risk-summary-item span { font-size: 1.3rem; font-weight: bold; color: #333; }
        
        .strategy-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin: 1.5rem 0;
        }
        
        .strategy-card {
            border: 2px solid #ddd;
            border-radius: 10px;
            padding: 1.5rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .strategy-card:hover { border-color: #667eea; background: #f8f9fa; }
        .strategy-card.selected { border-color: #667eea; background: #667eea; color: white; }
        .strategy-card h4 { margin-bottom: 0.5rem; }
        .strategy-card p { font-size: 0.9rem; opacity: 0.8; }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
            font-size: 0.95rem;
        }
        
        .form-group select, .form-group input, .form-group textarea {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            font-family: inherit;
        }
        
        .form-group select:focus, .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .control-list {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 1rem;
        }
        
        .control-item {
            padding: 1rem;
            margin-bottom: 0.8rem;
            border: 2px solid #e9ecef;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .control-item:hover { border-color: #667eea; background: #f8f9fa; }
        .control-item.selected { border-color: #667eea; background: #667eea15; }
        
        .control-item h4 { margin-bottom: 0.5rem; color: #333; }
        .control-item .cost-info {
            font-size: 0.85rem;
            color: #666;
            margin-top: 0.5rem;
        }
        
        .cost-benefit-display {
            background: #fff3cd;
            padding: 1.5rem;
            border-radius: 10px;
            margin-top: 1.5rem;
            border-left: 5px solid #ffc107;
        }
        
        .cost-benefit-display h3 { color: #856404; margin-bottom: 1rem; }
        .cost-benefit-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
        }
        .cost-benefit-item {
            background: white;
            padding: 1rem;
            border-radius: 5px;
        }
        .cost-benefit-item strong { display: block; font-size: 0.85rem; color: #666; }
        .cost-benefit-item .value { font-size: 1.5rem; font-weight: bold; color: #333; margin-top: 0.5rem; }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .risk-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .risk-極低 { background: #d4edda; color: #155724; }
        .risk-低 { background: #d1ecf1; color: #0c5460; }
        .risk-中 { background: #fff3cd; color: #856404; }
        .risk-高 { background: #f8d7da; color: #721c24; }
        .risk-極高 { background: #dc3545; color: white; }
        
        .status-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .status-規劃中 { background: #fff3cd; color: #856404; }
        .status-執行中 { background: #cfe2ff; color: #084298; }
        .status-已完成 { background: #d4edda; color: #155724; }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
        }
        
        .tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #dee2e6;
        }
        .tab {
            padding: 0.8rem 1.5rem;
            background: white;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            border-radius: 5px 5px 0 0;
        }
        .tab.active { background: #667eea; color: white; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($message)): ?>
        <div class="alert">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab(0)">🎯 新增處理計畫</button>
            <button class="tab" onclick="switchTab(1)">📋 處理計畫列表</button>
        </div>
        
        <!-- Tab 1: 新增處理計畫 -->
        <div class="tab-content active">
            <form method="POST" id="treatmentForm">
                <input type="hidden" name="action" value="save_treatment">
                
                <div class="card">
                    <h2>選擇要處理的風險</h2>
                    <div class="form-group">
                        <label>選擇風險評估 *</label>
                        <select name="risk_assessment_id" id="risk_select" required onchange="loadRiskInfo()">
                            <option value="">請選擇風險</option>
                            <?php foreach ($pending_risks as $risk): ?>
                            <option value="<?php echo $risk['id']; ?>"
                                    <?php echo ($selected_risk && $selected_risk['id'] == $risk['id']) ? 'selected' : ''; ?>
                                    data-score="<?php echo $risk['risk_score']; ?>"
                                    data-level="<?php echo $risk['risk_level']; ?>"
                                    data-asset="<?php echo htmlspecialchars($risk['asset_name']); ?>"
                                    data-threat="<?php echo htmlspecialchars($risk['threat_name']); ?>">
                                <?php echo $risk['assessment_code']; ?> - <?php echo $risk['asset_name']; ?> 
                                (風險: <?php echo $risk['risk_level']; ?>, 分數: <?php echo $risk['risk_score']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div id="riskSummary" style="display: none;">
                        <div class="risk-summary">
                            <h3>風險資訊摘要</h3>
                            <div class="risk-summary-grid">
                                <div class="risk-summary-item">
                                    <strong>資產名稱</strong>
                                    <span id="summary_asset">-</span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>威脅類型</strong>
                                    <span id="summary_threat">-</span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>風險分數</strong>
                                    <span id="summary_score">-</span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>風險等級</strong>
                                    <span id="summary_level">-</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>選擇處理策略</h2>
                    <div class="info-box">
                        <strong>說明：</strong>根據風險等級和組織風險偏好，選擇最適當的處理策略。系統將自動計算成本效益。
                    </div>
                    
                    <input type="hidden" name="treatment_strategy" id="strategy_value" value="">
                    <div class="strategy-grid">
                        <div class="strategy-card" onclick="selectStrategy('降低')">
                            <h4>🛡️ 降低風險</h4>
                            <p>實施控制措施降低風險至可接受範圍</p>
                        </div>
                        <div class="strategy-card" onclick="selectStrategy('轉移')">
                            <h4>🔄 轉移風險</h4>
                            <p>透過保險或外包將風險轉移給第三方</p>
                        </div>
                        <div class="strategy-card" onclick="selectStrategy('避免')">
                            <h4>🚫 避免風險</h4>
                            <p>停止或不進行會產生風險的活動</p>
                        </div>
                        <div class="strategy-card" onclick="selectStrategy('接受')">
                            <h4>✅ 接受風險</h4>
                            <p>當風險等級低或處理成本過高時接受風險</p>
                        </div>
                    </div>
                </div>
                
                <div class="card" id="controlSection" style="display: none;">
                    <h2>選擇控制措施</h2>
                    <div class="info-box">
                        <strong>說明：</strong>選擇一個或多個控制措施來降低風險。系統會顯示每個措施的成本和效益。
                    </div>
                    
                    <input type="hidden" name="control_measure_id" id="control_value" value="">
                    <div class="control-list">
                        <?php foreach ($control_measures as $control): ?>
                        <div class="control-item" onclick="selectControl(<?php echo $control['id']; ?>, <?php echo $control['implementation_cost']; ?>, <?php echo $control['annual_cost']; ?>, <?php echo $control['effectiveness']; ?>)">
                            <h4><?php echo htmlspecialchars($control['control_name']); ?></h4>
                            <p style="font-size: 0.9rem; color: #666; margin: 0.5rem 0;">
                                <?php echo htmlspecialchars($control['control_desc']); ?>
                            </p>
                            <div class="cost-info">
                                類型: <?php echo $control['control_type']; ?> | 
                                有效性: <?php echo $control['effectiveness']; ?>/5 | 
                                實施成本: $<?php echo number_format($control['implementation_cost']); ?> | 
                                年度成本: $<?php echo number_format($control['annual_cost']); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div id="costBenefitDisplay" style="display: none;" class="cost-benefit-display">
                        <h3>💰 成本效益分析</h3>
                        <div class="cost-benefit-grid">
                            <div class="cost-benefit-item">
                                <strong>風險價值估算</strong>
                                <div class="value" id="risk_value">$0</div>
                            </div>
                            <div class="cost-benefit-item">
                                <strong>控制措施總成本(3年)</strong>
                                <div class="value" id="control_cost">$0</div>
                            </div>
                            <div class="cost-benefit-item">
                                <strong>成本效益比</strong>
                                <div class="value" id="cost_benefit_ratio">0</div>
                            </div>
                        </div>
                        <p style="margin-top: 1rem; color: #856404;">
                            <strong>說明：</strong>成本效益比 = (風險降低價值 - 實施成本) / 實施成本。
                            比值越高表示投資回報越好。建議選擇比值 > 1 的控制措施。
                        </p>
                    </div>
                </div>
                
                <div class="card">
                    <h2>殘餘風險評估</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>殘餘風險等級 *</label>
                            <select name="residual_risk_level" required>
                                <option value="">請選擇</option>
                                <option value="極低">極低</option>
                                <option value="低">低</option>
                                <option value="中">中</option>
                                <option value="高">高</option>
                                <option value="極高">極高</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>殘餘風險分數 *</label>
                            <input type="number" name="residual_risk_score" step="0.01" required>
                        </div>
                        
                        <div class="form-group">
                            <label>執行優先順序 *</label>
                            <select name="implementation_priority" required>
                                <option value="">請選擇</option>
                                <option value="高">高</option>
                                <option value="中">中</option>
                                <option value="低">低</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>負責人 *</label>
                            <input type="text" name="responsible_person" required>
                        </div>
                        
                        <div class="form-group">
                            <label>目標完成日期</label>
                            <input type="date" name="target_date">
                        </div>
                    </div>
                    
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>備註</label>
                        <textarea name="notes" rows="3"></textarea>
                    </div>
                    
                    <div style="margin-top: 2rem;">
                        <button type="submit" class="btn">💾 建立處理計畫</button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Tab 2: 處理計畫列表 -->
        <div class="tab-content">
            <div class="card">
                <h2>📋 風險處理計畫列表</h2>
                <table>
                    <thead>
                        <tr>
                            <th>評估編號</th>
                            <th>資產</th>
                            <th>原風險</th>
                            <th>處理策略</th>
                            <th>控制措施</th>
                            <th>殘餘風險</th>
                            <th>成本效益比</th>
                            <th>狀態</th>
                            <th>負責人</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($treatments as $treatment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($treatment['assessment_code']); ?></td>
                            <td><?php echo htmlspecialchars($treatment['asset_name']); ?></td>
                            <td>
                                <span class="risk-badge risk-<?php echo $treatment['risk_level']; ?>">
                                    <?php echo $treatment['risk_level']; ?> (<?php echo $treatment['risk_score']; ?>)
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($treatment['treatment_strategy']); ?></td>
                            <td><?php echo $treatment['control_name'] ? htmlspecialchars($treatment['control_name']) : '-'; ?></td>
                            <td>
                                <span class="risk-badge risk-<?php echo $treatment['residual_risk_level']; ?>">
                                    <?php echo $treatment['residual_risk_level']; ?>
                                </span>
                            </td>
                            <td><strong><?php echo $treatment['cost_benefit_ratio'] ? number_format($treatment['cost_benefit_ratio'], 2) : '-'; ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo $treatment['status']; ?>">
                                    <?php echo htmlspecialchars($treatment['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($treatment['responsible_person']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function switchTab(index) {
            const tabs = document.querySelectorAll('.tab');
            const contents = document.querySelectorAll('.tab-content');
            tabs.forEach((tab, i) => {
                if (i === index) {
                    tab.classList.add('active');
                    contents[i].classList.add('active');
                } else {
                    tab.classList.remove('active');
                    contents[i].classList.remove('active');
                }
            });
        }
        
        function loadRiskInfo() {
            const select = document.getElementById('risk_select');
            const option = select.options[select.selectedIndex];
            
            if (option.value) {
                document.getElementById('riskSummary').style.display = 'block';
                document.getElementById('summary_asset').textContent = option.dataset.asset;
                document.getElementById('summary_threat').textContent = option.dataset.threat;
                document.getElementById('summary_score').textContent = option.dataset.score;
                document.getElementById('summary_level').textContent = option.dataset.level;
                
                // 儲存風險分數供後續計算使用
                window.currentRiskScore = parseFloat(option.dataset.score);
            }
        }
        
        function selectStrategy(strategy) {
            document.getElementById('strategy_value').value = strategy;
            
            document.querySelectorAll('.strategy-card').forEach(card => {
                card.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
            
            // 只有選擇"降低"時才顯示控制措施
            if (strategy === '降低') {
                document.getElementById('controlSection').style.display = 'block';
            } else {
                document.getElementById('controlSection').style.display = 'none';
            }
        }
        
        function selectControl(id, implCost, annualCost, effectiveness) {
            document.getElementById('control_value').value = id;
            
            document.querySelectorAll('.control-item').forEach(item => {
                item.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
            
            // 計算成本效益
            calculateCostBenefit(implCost, annualCost, effectiveness);
        }
        
        function calculateCostBenefit(implCost, annualCost, effectiveness) {
            if (!window.currentRiskScore) return;
            
            const riskValue = window.currentRiskScore * 100000;
            const totalCost = implCost + (annualCost * 3);
            const costBenefitRatio = totalCost > 0 ? (riskValue - totalCost) / totalCost : 0;
            
            document.getElementById('costBenefitDisplay').style.display = 'block';
            document.getElementById('risk_value').textContent = '$' + riskValue.toLocaleString();
            document.getElementById('control_cost').textContent = '$' + totalCost.toLocaleString();
            document.getElementById('cost_benefit_ratio').textContent = costBenefitRatio.toFixed(2);
            
            // 根據成本效益比改變顏色
            const ratioElement = document.getElementById('cost_benefit_ratio');
            if (costBenefitRatio > 5) {
                ratioElement.style.color = '#28a745';
            } else if (costBenefitRatio > 1) {
                ratioElement.style.color = '#ffc107';
            } else {
                ratioElement.style.color = '#dc3545';
            }
        }
        
        // 頁面載入時如果有選中的風險，自動載入資訊
        window.onload = function() {
            const select = document.getElementById('risk_select');
            if (select.value) {
                loadRiskInfo();
            }
        };
    </script>
</body>
</html>