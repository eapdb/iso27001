<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 主界面 - 風險評估儀表板
 */
require_once 'config.php';

// 取得統計資料
$total_assets = fetchOne("SELECT COUNT(*) as count FROM assets")['count'];
$total_risks = fetchOne("SELECT COUNT(*) as count FROM risk_assessments")['count'];
$high_risks = fetchOne("SELECT COUNT(*) as count FROM risk_assessments WHERE risk_level IN ('高', '極高')")['count'];
$pending_treatments = fetchOne("SELECT COUNT(*) as count FROM risk_treatments WHERE status IN ('規劃中', '待審核')")['count'];

// 取得風險分布統計
$risk_distribution = fetchAll("
    SELECT risk_level, COUNT(*) as count 
    FROM risk_assessments 
    GROUP BY risk_level 
    ORDER BY FIELD(risk_level, '極低', '低', '中', '高', '極高')
");

// 取得最近的風險評估
$recent_risks = fetchAll("
    SELECT ra.*, a.asset_name, t.threat_name 
    FROM risk_assessments ra
    JOIN assets a ON ra.asset_id = a.id
    JOIN threat_types t ON ra.threat_id = t.id
    ORDER BY ra.created_at DESC
    LIMIT 10
");
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        /* 導航列 */
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a {
            color: white;
            text-decoration: none;
            margin-right: 1.5rem;
            font-weight: 500;
            padding: 0.3rem 0;
            border-bottom: 2px solid transparent;
            transition: border-color 0.3s;
        }
        .navbar nav a:hover { border-bottom-color: white; }
        
        /* 容器 */
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        /* 統計卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.12);
        }
        .stat-card h3 { color: #666; font-size: 0.9rem; margin-bottom: 0.5rem; }
        .stat-card .value { font-size: 2.5rem; font-weight: bold; color: #667eea; }
        .stat-card.danger .value { color: #e74c3c; }
        .stat-card.warning .value { color: #f39c12; }
        
        /* 內容區塊 */
        .content-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
        .card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .card h2 {
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        /* 圖表 */
        .chart-container { padding: 1rem 0; }
        .chart-bar {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        .chart-label {
            width: 80px;
            font-size: 0.9rem;
            color: #666;
        }
        .chart-bar-fill {
            flex: 1;
            height: 30px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            padding-left: 10px;
            color: white;
            font-weight: bold;
            transition: width 0.5s ease;
        }
        
        /* 表格 */
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        /* 風險等級標籤 */
        .risk-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .risk-極低 { background: #d4edda; color: #155724; }
        .risk-低 { background: #d1ecf1; color: #0c5460; }
        .risk-中 { background: #fff3cd; color: #856404; }
        .risk-高 { background: #f8d7da; color: #721c24; }
        .risk-極高 { background: #dc3545; color: white; }
        
        /* 按鈕 */
        .btn {
            display: inline-block;
            padding: 0.6rem 1.2rem;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        /* 快速動作 */
        .quick-actions {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        @media (max-width: 768px) {
            .content-grid { grid-template-columns: 1fr; }
            .navbar nav { margin-top: 1rem; }
            .navbar nav a { display: inline-block; margin-bottom: 0.5rem; }
        }
    </style>
</head>
<body>
    <!-- 導航列 -->
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
            <a href="settings.php">系統設定</a>
        </nav>
    </div>
    
    <!-- 主要容器 -->
    <div class="container">
        <!-- 快速動作 -->
        <div class="quick-actions">
            <a href="risk_assessment.php?action=new" class="btn">+ 新增風險評估</a>
            <a href="assets.php?action=new" class="btn btn-success">+ 新增資產</a>
        </div>
        
        <!-- 統計卡片 -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>總資產數量</h3>
                <div class="value"><?php echo $total_assets; ?></div>
            </div>
            <div class="stat-card">
                <h3>風險評估總數</h3>
                <div class="value"><?php echo $total_risks; ?></div>
            </div>
            <div class="stat-card danger">
                <h3>高風險項目</h3>
                <div class="value"><?php echo $high_risks; ?></div>
            </div>
            <div class="stat-card warning">
                <h3>待處理項目</h3>
                <div class="value"><?php echo $pending_treatments; ?></div>
            </div>
        </div>
        
        <!-- 內容區塊 -->
        <div class="content-grid">
            <!-- 風險分布圖 -->
            <div class="card">
                <h2>📊 風險等級分布</h2>
                <div class="chart-container">
                    <?php
                    $colors = [
                        '極低' => '#28a745',
                        '低' => '#17a2b8',
                        '中' => '#ffc107',
                        '高' => '#dc3545',
                        '極高' => '#6c0000'
                    ];
                    $max_count = max(array_column($risk_distribution, 'count'));
                    foreach ($risk_distribution as $item):
                        $percentage = $max_count > 0 ? ($item['count'] / $max_count * 100) : 0;
                    ?>
                    <div class="chart-bar">
                        <div class="chart-label"><?php echo $item['risk_level']; ?></div>
                        <div class="chart-bar-fill" style="width: <?php echo $percentage; ?>%; background: <?php echo $colors[$item['risk_level']]; ?>;">
                            <?php echo $item['count']; ?> 項
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- 最近風險評估 -->
            <div class="card">
                <h2>🔍 最近的風險評估</h2>
                <table>
                    <thead>
                        <tr>
                            <th>評估編號</th>
                            <th>資產名稱</th>
                            <th>威脅</th>
                            <th>風險等級</th>
                            <th>狀態</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($recent_risks, 0, 5) as $risk): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($risk['assessment_code']); ?></td>
                            <td><?php echo htmlspecialchars($risk['asset_name']); ?></td>
                            <td><?php echo htmlspecialchars(mb_substr($risk['threat_name'], 0, 15)); ?></td>
                            <td>
                                <span class="risk-badge risk-<?php echo $risk['risk_level']; ?>">
                                    <?php echo $risk['risk_level']; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($risk['status']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div style="margin-top: 1rem; text-align: right;">
                    <a href="risk_assessment.php" class="btn">查看全部</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>