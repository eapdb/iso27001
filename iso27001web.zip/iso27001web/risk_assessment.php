<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 風險評估主界面 - 實現四大核心功能
 * 1. 識別資產及其對組織的價值
 * 2. 確定威脅利用漏洞的可能性
 * 3. 確定潛在威脅的業務影響
 * 4. 在威脅影響和安全對策成本之間達到經濟平衡
 */
require_once 'config.php';

// 處理表單提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save_assessment') {
        // 1. 識別資產及其價值
        $asset_id = $_POST['asset_id'];
        $asset = fetchOne("SELECT * FROM assets WHERE id = ?", [$asset_id]);
        
        // 2. 確定威脅利用漏洞的可能性
        $threat_likelihood = intval($_POST['threat_likelihood']);
        $vulnerability_severity = intval($_POST['vulnerability_severity']);
        $combined_likelihood = round(($threat_likelihood + $vulnerability_severity) / 2);
        
        // 3. 確定潛在威脅的業務影響
        $impact_c = intval($_POST['impact_confidentiality']);
        $impact_i = intval($_POST['impact_integrity']);
        $impact_a = intval($_POST['impact_availability']);
        
        // 結合資產的CIA價值計算綜合影響
        $weighted_impact_c = round(($impact_c + $asset['confidentiality_value']) / 2);
        $weighted_impact_i = round(($impact_i + $asset['integrity_value']) / 2);
        $weighted_impact_a = round(($impact_a + $asset['availability_value']) / 2);
        
        // 計算整體影響值
        $overall_impact = calculateOverallImpact(
            $weighted_impact_c,
            $weighted_impact_i,
            $weighted_impact_a,
            $asset['business_value']
        );
        
        // 根據風險矩陣計算風險等級和分數
        $risk_result = calculateRiskScore($combined_likelihood, $overall_impact);
        
        // 生成評估編號
        $assessment_code = 'RA-' . date('Y') . '-' . str_pad(
            fetchOne("SELECT COUNT(*) + 1 as next_id FROM risk_assessments")['next_id'],
            3, '0', STR_PAD_LEFT
        );
        
        // 插入風險評估
        $sql = "INSERT INTO risk_assessments (
            assessment_code, asset_id, threat_id, vulnerability_id,
            threat_likelihood, vulnerability_severity,
            impact_confidentiality, impact_integrity, impact_availability,
            impact_financial, impact_reputation, impact_legal,
            risk_level, risk_score, assessment_date, assessor, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $assessment_code,
            $asset_id,
            $_POST['threat_id'],
            $_POST['vulnerability_id'],
            $threat_likelihood,
            $vulnerability_severity,
            $impact_c,
            $impact_i,
            $impact_a,
            $_POST['impact_financial'],
            $_POST['impact_reputation'],
            $_POST['impact_legal'],
            $risk_result['risk_level'],
            $risk_result['risk_score'],
            $_POST['assessment_date'],
            $_POST['assessor'],
            '待處理'
        ];
        
        $risk_id = insertAndGetId($sql, $params);
        
        // 4. 自動推薦控制措施並計算成本效益
        $recommended_controls = fetchAll("
            SELECT cm.*, 
                   (? * 100000 - cm.implementation_cost - cm.annual_cost * 3) / 
                   (cm.implementation_cost + cm.annual_cost * 3) as cost_benefit
            FROM control_measures cm
            WHERE cm.is_active = 1
            AND cm.effectiveness >= 3
            ORDER BY cost_benefit DESC
            LIMIT 5
        ", [$risk_result['risk_score']]);
        
        $success_message = "風險評估已成功儲存！編號: {$assessment_code}";
    }
}

// 取得所有資產
$assets = fetchAll("
    SELECT a.*, ac.category_name 
    FROM assets a 
    LEFT JOIN asset_categories ac ON a.category_id = ac.id 
    WHERE a.id > 0
    ORDER BY a.asset_code
");

// 取得威脅類型
$threats = fetchAll("SELECT * FROM threat_types WHERE is_active = 1 ORDER BY display_order");

// 取得漏洞列表
$vulnerabilities = fetchAll("SELECT * FROM vulnerabilities WHERE is_active = 1 ORDER BY display_order");

// 取得可能性和影響等級
$likelihood_levels = fetchAll("SELECT * FROM likelihood_levels ORDER BY level_value");
$impact_levels = fetchAll("SELECT * FROM impact_levels ORDER BY level_value");

// 取得所有風險評估記錄
$risk_assessments = fetchAll("
    SELECT ra.*, 
           a.asset_name, a.asset_code,
           t.threat_name,
           v.vulnerability_name
    FROM risk_assessments ra
    JOIN assets a ON ra.asset_id = a.id
    JOIN threat_types t ON ra.threat_id = t.id
    LEFT JOIN vulnerabilities v ON ra.vulnerability_id = v.id
    ORDER BY ra.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>風險評估 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a {
            color: white;
            text-decoration: none;
            margin-right: 1.5rem;
            font-weight: 500;
        }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #dee2e6;
        }
        .tab {
            padding: 0.8rem 1.5rem;
            background: white;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            border-radius: 5px 5px 0 0;
            transition: background 0.3s;
        }
        .tab.active {
            background: #667eea;
            color: white;
            font-weight: 600;
        }
        .tab:hover:not(.active) { background: #f8f9fa; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
            font-size: 0.95rem;
        }
        
        .form-group select,
        .form-group input {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }
        
        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .value-indicator {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .value-box {
            flex: 1;
            text-align: center;
            padding: 0.5rem;
            border-radius: 5px;
            font-size: 0.85rem;
            background: #f8f9fa;
        }
        
        .value-box.active {
            background: #667eea;
            color: white;
            font-weight: bold;
        }
        
        .risk-matrix-preview {
            margin: 1.5rem 0;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 10px;
            border: 2px dashed #dee2e6;
        }
        
        .risk-matrix-preview h3 {
            margin-bottom: 1rem;
            color: #667eea;
        }
        
        .risk-result {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.1rem;
        }
        
        .risk-score-big {
            font-size: 3rem;
            font-weight: bold;
            color: #667eea;
        }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover { background: #5a6268; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .risk-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .risk-極低 { background: #d4edda; color: #155724; }
        .risk-低 { background: #d1ecf1; color: #0c5460; }
        .risk-中 { background: #fff3cd; color: #856404; }
        .risk-高 { background: #f8d7da; color: #721c24; }
        .risk-極高 { background: #dc3545; color: white; }
        
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #667eea;
            margin: 2rem 0 1rem 0;
            padding-left: 1rem;
            border-left: 4px solid #667eea;
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 5px;
        }
        
        .control-recommendation {
            background: #fff3cd;
            padding: 1.5rem;
            border-radius: 5px;
            margin-top: 1.5rem;
        }
        
        .control-item {
            padding: 1rem;
            background: white;
            margin-bottom: 0.8rem;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .cost-benefit-badge {
            background: #28a745;
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($success_message)): ?>
        <div class="alert">
            ✓ <?php echo $success_message; ?>
        </div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab(0)">📝 新增風險評估</button>
            <button class="tab" onclick="switchTab(1)">📋 評估記錄</button>
        </div>
        
        <!-- Tab 1: 新增風險評估 -->
        <div class="tab-content active">
            <form method="POST" id="assessmentForm">
                <input type="hidden" name="action" value="save_assessment">
                
                <div class="card">
                    <h2>1️⃣ 識別資產及其對組織的價值</h2>
                    <div class="info-box">
                        <strong>說明：</strong>選擇要評估的資產，系統將自動載入該資產的機密性(C)、完整性(I)、可用性(A)及業務價值，作為風險計算的基礎。
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>選擇資產 *</label>
                            <select name="asset_id" id="asset_id" required onchange="loadAssetInfo()">
                                <option value="">請選擇資產</option>
                                <?php foreach ($assets as $asset): ?>
                                <option value="<?php echo $asset['id']; ?>" 
                                    data-c="<?php echo $asset['confidentiality_value']; ?>"
                                    data-i="<?php echo $asset['integrity_value']; ?>"
                                    data-a="<?php echo $asset['availability_value']; ?>"
                                    data-bv="<?php echo $asset['business_value']; ?>">
                                    <?php echo htmlspecialchars($asset['asset_code'] . ' - ' . $asset['asset_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div id="assetValueDisplay" style="display:none; margin-top: 1rem;">
                        <div class="section-title">資產價值評估</div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>機密性(Confidentiality)價值</label>
                                <div class="value-indicator" id="c-indicator">
                                    <div class="value-box">1</div>
                                    <div class="value-box">2</div>
                                    <div class="value-box">3</div>
                                    <div class="value-box">4</div>
                                    <div class="value-box">5</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>完整性(Integrity)價值</label>
                                <div class="value-indicator" id="i-indicator">
                                    <div class="value-box">1</div>
                                    <div class="value-box">2</div>
                                    <div class="value-box">3</div>
                                    <div class="value-box">4</div>
                                    <div class="value-box">5</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>可用性(Availability)價值</label>
                                <div class="value-indicator" id="a-indicator">
                                    <div class="value-box">1</div>
                                    <div class="value-box">2</div>
                                    <div class="value-box">3</div>
                                    <div class="value-box">4</div>
                                    <div class="value-box">5</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>業務價值(Business Value)</label>
                                <div class="value-indicator" id="bv-indicator">
                                    <div class="value-box">1</div>
                                    <div class="value-box">2</div>
                                    <div class="value-box">3</div>
                                    <div class="value-box">4</div>
                                    <div class="value-box">5</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>2️⃣ 確定威脅利用漏洞的可能性</h2>
                    <div class="info-box">
                        <strong>說明：</strong>評估特定威脅發生的可能性，以及現有漏洞被利用的嚴重程度。系統將綜合這兩個因素計算風險可能性。
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>威脅類型 *</label>
                            <select name="threat_id" required>
                                <option value="">請選擇威脅</option>
                                <?php foreach ($threats as $threat): ?>
                                <option value="<?php echo $threat['id']; ?>">
                                    <?php echo htmlspecialchars($threat['threat_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>漏洞 *</label>
                            <select name="vulnerability_id" required>
                                <option value="">請選擇漏洞</option>
                                <?php foreach ($vulnerabilities as $vuln): ?>
                                <option value="<?php echo $vuln['id']; ?>">
                                    <?php echo htmlspecialchars($vuln['vulnerability_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>威脅發生可能性 * (1-5)</label>
                            <select name="threat_likelihood" id="threat_likelihood" required onchange="calculateRisk()">
                                <option value="">請選擇</option>
                                <?php foreach ($likelihood_levels as $level): ?>
                                <option value="<?php echo $level['level_value']; ?>">
                                    <?php echo $level['level_value']; ?> - <?php echo $level['level_name']; ?>
                                    (<?php echo $level['probability_percentage']; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>漏洞嚴重程度 * (1-5)</label>
                            <select name="vulnerability_severity" id="vulnerability_severity" required onchange="calculateRisk()">
                                <option value="">請選擇</option>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?> - <?php echo ['', '極低', '低', '中', '高', '極高'][$i]; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>3️⃣ 確定潛在威脅的業務影響</h2>
                    <div class="info-box">
                        <strong>說明：</strong>評估威脅實現後對組織的實際影響，包括對CIA三個面向及財務、聲譽、法律等方面的影響。
                    </div>
                    
                    <div class="section-title">資訊安全影響評估</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>機密性影響 * (1-5)</label>
                            <select name="impact_confidentiality" id="impact_confidentiality" required onchange="calculateRisk()">
                                <option value="">請選擇</option>
                                <?php foreach ($impact_levels as $level): ?>
                                <option value="<?php echo $level['level_value']; ?>">
                                    <?php echo $level['level_value']; ?> - <?php echo $level['level_name']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>完整性影響 * (1-5)</label>
                            <select name="impact_integrity" id="impact_integrity" required onchange="calculateRisk()">
                                <option value="">請選擇</option>
                                <?php foreach ($impact_levels as $level): ?>
                                <option value="<?php echo $level['level_value']; ?>">
                                    <?php echo $level['level_value']; ?> - <?php echo $level['level_name']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>可用性影響 * (1-5)</label>
                            <select name="impact_availability" id="impact_availability" required onchange="calculateRisk()">
                                <option value="">請選擇</option>
                                <?php foreach ($impact_levels as $level): ?>
                                <option value="<?php echo $level['level_value']; ?>">
                                    <?php echo $level['level_value']; ?> - <?php echo $level['level_name']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="section-title">業務影響評估</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>財務影響估計 (TWD)</label>
                            <input type="number" name="impact_financial" step="0.01" value="0">
                        </div>
                        
                        <div class="form-group">
                            <label>聲譽影響 * (1-5)</label>
                            <select name="impact_reputation" required>
                                <option value="">請選擇</option>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?> - <?php echo ['', '極低', '低', '中', '高', '極高'][$i]; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>法律合規影響 * (1-5)</label>
                            <select name="impact_legal" required>
                                <option value="">請選擇</option>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?> - <?php echo ['', '極低', '低', '中', '高', '極高'][$i]; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- 風險計算預覽 -->
                <div class="risk-matrix-preview" id="riskPreview" style="display:none;">
                    <h3>🎯 風險等級預覽</h3>
                    <div class="risk-result">
                        <div>
                            <div style="font-size: 0.9rem; color: #666;">風險分數</div>
                            <div class="risk-score-big" id="previewScore">-</div>
                        </div>
                        <div>
                            <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">風險等級</div>
                            <span class="risk-badge" id="previewLevel" style="font-size: 1.2rem; padding: 0.5rem 1.5rem;">-</span>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($recommended_controls) && count($recommended_controls) > 0): ?>
                <div class="control-recommendation">
                    <h3 style="margin-bottom: 1rem; color: #856404;">💡 4️⃣ 推薦的控制措施與成本效益分析</h3>
                    <div class="info-box" style="background: white;">
                        <strong>說明：</strong>系統根據風險等級自動推薦最具成本效益的控制措施。成本效益比 = (風險降低價值 - 實施成本) / 實施成本
                    </div>
                    <?php foreach ($recommended_controls as $control): ?>
                    <div class="control-item">
                        <div>
                            <strong><?php echo htmlspecialchars($control['control_name']); ?></strong>
                            <div style="font-size: 0.85rem; color: #666; margin-top: 0.3rem;">
                                類型: <?php echo $control['control_type']; ?> | 
                                實施成本: $<?php echo number_format($control['implementation_cost']); ?> | 
                                年度成本: $<?php echo number_format($control['annual_cost']); ?>
                            </div>
                        </div>
                        <div class="cost-benefit-badge">
                            效益比: <?php echo number_format($control['cost_benefit'], 2); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                <div class="card">
                    <h2>評估資訊</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>評估日期 *</label>
                            <input type="date" name="assessment_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>評估人員 *</label>
                            <input type="text" name="assessor" required placeholder="請輸入評估人員姓名">
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn">💾 儲存風險評估</button>
                        <button type="reset" class="btn btn-secondary">🔄 重設表單</button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Tab 2: 評估記錄 -->
        <div class="tab-content">
            <div class="card">
                <h2>📋 風險評估記錄列表</h2>
                <table>
                    <thead>
                        <tr>
                            <th>評估編號</th>
                            <th>資產</th>
                            <th>威脅</th>
                            <th>漏洞</th>
                            <th>風險分數</th>
                            <th>風險等級</th>