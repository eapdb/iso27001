<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 資料庫連線設定檔
 */

// 資料庫連線參數
define('DB_HOST', 'localhost');
define('DB_NAME', 'iso27001_risk_system');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// 建立PDO連線
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        die("資料庫連線失敗: " . $e->getMessage());
    }
}

// 通用查詢函數
function executeQuery($sql, $params = []) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// 取得單一記錄
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}

// 取得多筆記錄
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

// 插入資料並返回ID
function insertAndGetId($sql, $params = []) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $pdo->lastInsertId();
}

// 取得系統設定
function getSystemConfig($key) {
    $result = fetchOne("SELECT config_value FROM system_config WHERE config_key = ?", [$key]);
    return $result ? $result['config_value'] : null;
}

// 計算風險分數 (可能性 x 影響)
function calculateRiskScore($likelihood, $impact) {
    $matrix = fetchOne(
        "SELECT risk_score, risk_level, color_code FROM risk_matrix WHERE likelihood_value = ? AND impact_value = ?",
        [$likelihood, $impact]
    );
    return $matrix;
}

// 計算綜合影響值 (CIA + 業務價值)
function calculateOverallImpact($confidentiality, $integrity, $availability, $business_value) {
    // 使用加權平均計算綜合影響
    return round(($confidentiality + $integrity + $availability + $business_value) / 4);
}

// 設定時區
date_default_timezone_set('Asia/Taipei');

// 頁面標題
$page_title = 'ISO 27001:2022 風險評估與管理系統';
?>