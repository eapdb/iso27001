-- ISO 27001:2022 風險評估與管理系統資料庫

CREATE DATABASE IF NOT EXISTS iso27001_risk_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE iso27001_risk_system;

-- 系統設定表
CREATE TABLE system_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT,
    config_desc VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 資產類別表
CREATE TABLE asset_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL,
    category_desc TEXT,
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 資產表
CREATE TABLE assets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    asset_code VARCHAR(50) UNIQUE NOT NULL,
    asset_name VARCHAR(200) NOT NULL,
    category_id INT,
    description TEXT,
    owner VARCHAR(100),
    location VARCHAR(200),
    confidentiality_value INT DEFAULT 1 COMMENT '機密性價值 1-5',
    integrity_value INT DEFAULT 1 COMMENT '完整性價值 1-5',
    availability_value INT DEFAULT 1 COMMENT '可用性價值 1-5',
    business_value INT DEFAULT 1 COMMENT '業務價值 1-5',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES asset_categories(id)
);

-- 威脅類型表
CREATE TABLE threat_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    threat_name VARCHAR(200) NOT NULL,
    threat_desc TEXT,
    threat_category VARCHAR(100),
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 漏洞表
CREATE TABLE vulnerabilities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vulnerability_name VARCHAR(200) NOT NULL,
    vulnerability_desc TEXT,
    vulnerability_type VARCHAR(100),
    ease_of_exploitation INT DEFAULT 1 COMMENT '利用難度 1-5',
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 風險評估表
CREATE TABLE risk_assessments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    assessment_code VARCHAR(50) UNIQUE NOT NULL,
    asset_id INT NOT NULL,
    threat_id INT NOT NULL,
    vulnerability_id INT,
    threat_likelihood INT DEFAULT 1 COMMENT '威脅可能性 1-5',
    vulnerability_severity INT DEFAULT 1 COMMENT '漏洞嚴重程度 1-5',
    impact_confidentiality INT DEFAULT 1 COMMENT '機密性影響 1-5',
    impact_integrity INT DEFAULT 1 COMMENT '完整性影響 1-5',
    impact_availability INT DEFAULT 1 COMMENT '可用性影響 1-5',
    impact_financial DECIMAL(15,2) DEFAULT 0 COMMENT '財務影響估計',
    impact_reputation INT DEFAULT 1 COMMENT '聲譽影響 1-5',
    impact_legal INT DEFAULT 1 COMMENT '法律影響 1-5',
    risk_level VARCHAR(20) COMMENT '風險等級: 極低/低/中/高/極高',
    risk_score DECIMAL(10,2) COMMENT '風險分數',
    assessment_date DATE,
    assessor VARCHAR(100),
    status VARCHAR(50) DEFAULT '待處理',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id),
    FOREIGN KEY (threat_id) REFERENCES threat_types(id),
    FOREIGN KEY (vulnerability_id) REFERENCES vulnerabilities(id)
);

-- 控制措施表
CREATE TABLE control_measures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    control_code VARCHAR(50) UNIQUE NOT NULL,
    control_name VARCHAR(200) NOT NULL,
    control_desc TEXT,
    control_type VARCHAR(100) COMMENT '預防性/偵測性/矯正性',
    iso_annex_ref VARCHAR(50) COMMENT 'ISO 27001 附錄A參考',
    implementation_cost DECIMAL(15,2) DEFAULT 0,
    annual_cost DECIMAL(15,2) DEFAULT 0,
    effectiveness INT DEFAULT 1 COMMENT '有效性 1-5',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 風險處理計畫表
CREATE TABLE risk_treatments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    risk_assessment_id INT NOT NULL,
    treatment_strategy VARCHAR(50) COMMENT '接受/降低/轉移/避免',
    control_measure_id INT,
    residual_risk_level VARCHAR(20),
    residual_risk_score DECIMAL(10,2),
    implementation_priority VARCHAR(20) COMMENT '高/中/低',
    responsible_person VARCHAR(100),
    target_date DATE,
    actual_completion_date DATE,
    status VARCHAR(50) DEFAULT '規劃中',
    cost_benefit_ratio DECIMAL(10,2) COMMENT '成本效益比',
    approval_status VARCHAR(50) DEFAULT '待審核',
    approval_date DATE,
    approver VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (risk_assessment_id) REFERENCES risk_assessments(id),
    FOREIGN KEY (control_measure_id) REFERENCES control_measures(id)
);

-- 風險監控記錄表
CREATE TABLE risk_monitoring (
    id INT PRIMARY KEY AUTO_INCREMENT,
    risk_assessment_id INT NOT NULL,
    monitoring_date DATE,
    current_risk_level VARCHAR(20),
    current_risk_score DECIMAL(10,2),
    control_effectiveness INT COMMENT '控制有效性 1-5',
    incidents_occurred INT DEFAULT 0,
    monitoring_notes TEXT,
    monitor_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (risk_assessment_id) REFERENCES risk_assessments(id)
);

-- 影響等級設定表
CREATE TABLE impact_levels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    level_value INT UNIQUE NOT NULL,
    level_name VARCHAR(50) NOT NULL,
    level_desc TEXT,
    financial_range_min DECIMAL(15,2),
    financial_range_max DECIMAL(15,2),
    display_order INT DEFAULT 0
);

-- 可能性等級設定表
CREATE TABLE likelihood_levels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    level_value INT UNIQUE NOT NULL,
    level_name VARCHAR(50) NOT NULL,
    level_desc TEXT,
    probability_percentage VARCHAR(50),
    display_order INT DEFAULT 0
);

-- 風險矩陣設定表
CREATE TABLE risk_matrix (
    id INT PRIMARY KEY AUTO_INCREMENT,
    likelihood_value INT NOT NULL,
    impact_value INT NOT NULL,
    risk_level VARCHAR(20) NOT NULL,
    risk_score DECIMAL(10,2) NOT NULL,
    color_code VARCHAR(20),
    UNIQUE KEY unique_matrix (likelihood_value, impact_value)
);

-- ==================== 插入範例資料 ====================

-- 系統設定
INSERT INTO system_config (config_key, config_value, config_desc) VALUES
('company_name', '範例科技股份有限公司', '組織名稱'),
('risk_appetite', '中等', '風險偏好等級'),
('assessment_frequency', '12', '風險評估頻率(月)'),
('currency', 'TWD', '幣別'),
('high_risk_threshold', '15', '高風險門檻值'),
('medium_risk_threshold', '8', '中風險門檻值');

-- 資產類別
INSERT INTO asset_categories (category_name, category_desc, display_order) VALUES
('資訊系統', '包含應用系統、資料庫系統等', 1),
('硬體設備', '伺服器、網路設備、個人電腦等', 2),
('資料資產', '客戶資料、財務資料、智慧財產等', 3),
('人力資源', '關鍵人員、技術團隊等', 4),
('場所設施', '機房、辦公室等實體場所', 5),
('文件記錄', '政策、程序、合約等文件', 6);

-- 資產範例
INSERT INTO assets (asset_code, asset_name, category_id, description, owner, location, 
    confidentiality_value, integrity_value, availability_value, business_value) VALUES
('AS-001', '客戶關係管理系統(CRM)', 1, '儲存所有客戶資料與交易記錄的核心系統', '資訊部經理', '總部機房', 5, 5, 4, 5),
('AS-002', '財務管理系統', 1, '處理公司所有財務交易與報表', '財務部經理', '總部機房', 5, 5, 5, 5),
('AS-003', '主要資料庫伺服器', 2, 'Oracle資料庫伺服器，存放核心業務資料', '資訊部', '總部機房', 5, 5, 5, 5),
('AS-004', '網路防火牆', 2, '保護內部網路的主要防火牆設備', '網管組', '總部機房', 3, 5, 5, 4),
('AS-005', '客戶個資資料庫', 3, '包含10萬筆客戶個人資料', '資訊部', '總部機房', 5, 5, 4, 5),
('AS-006', '產品設計圖檔', 3, '公司核心產品的設計與技術文件', '研發部', '檔案伺服器', 5, 5, 3, 5),
('AS-007', '核心開發團隊', 4, '5位資深工程師組成的核心技術團隊', '技術長', '總部', 4, 4, 4, 5),
('AS-008', '主機房', 5, '放置所有核心IT設備的機房', '總務部', '總部3樓', 4, 4, 5, 5),
('AS-009', '資訊安全政策文件', 6, 'ISO 27001相關政策與程序文件', '資安長', '文管系統', 4, 5, 3, 4),
('AS-010', '備份系統', 1, '每日自動備份所有重要資料', '資訊部', '異地機房', 4, 5, 5, 4);

-- 威脅類型
INSERT INTO threat_types (threat_name, threat_desc, threat_category, display_order) VALUES
('惡意軟體攻擊', '病毒、木馬、勒索軟體等惡意程式攻擊', '技術威脅', 1),
('網路入侵', '駭客透過網路漏洞入侵系統', '技術威脅', 2),
('社交工程攻擊', '透過釣魚郵件或電話詐騙取得敏感資訊', '人為威脅', 3),
('內部人員濫用', '員工蓄意或無意洩露或破壞資料', '人為威脅', 4),
('服務中斷', 'DDoS攻擊或系統過載導致服務無法使用', '技術威脅', 5),
('資料洩露', '敏感資料被未授權存取或外洩', '技術威脅', 6),
('硬體故障', '伺服器、儲存設備等硬體損壞', '環境威脅', 7),
('天然災害', '火災、水災、地震等自然災害', '環境威脅', 8),
('電力中斷', '停電或電力供應不穩定', '環境威脅', 9),
('供應商風險', '第三方服務提供商的安全問題', '外部威脅', 10),
('法規變更', '新的資料保護法規要求', '法律威脅', 11),
('零日漏洞攻擊', '利用未知的系統漏洞進行攻擊', '技術威脅', 12);

-- 漏洞範例
INSERT INTO vulnerabilities (vulnerability_name, vulnerability_desc, vulnerability_type, ease_of_exploitation) VALUES
('缺乏定期修補程式更新', '系統未定期安裝安全修補程式', '技術漏洞', 3),
('弱密碼政策', '未強制複雜密碼或定期變更', '管理漏洞', 4),
('缺乏存取控制', '未實施適當的權限管理', '技術漏洞', 3),
('員工安全意識不足', '缺乏定期資安教育訓練', '人為漏洞', 5),
('無加密傳輸', '敏感資料傳輸未加密', '技術漏洞', 4),
('缺乏備份機制', '重要資料未定期備份', '管理漏洞', 2),
('單點故障', '關鍵系統無備援機制', '架構漏洞', 3),
('實體安全防護不足', '機房門禁管制不嚴', '實體漏洞', 3),
('缺乏監控與日誌', '未記錄或監控系統活動', '技術漏洞', 2),
('第三方未評估', '供應商安全性未經審查', '管理漏洞', 3),
('應急計畫不完整', '缺乏業務持續計畫或演練', '管理漏洞', 2),
('網路區隔不足', '內部網路未適當分段隔離', '架構漏洞', 3);

-- 影響等級設定
INSERT INTO impact_levels (level_value, level_name, level_desc, financial_range_min, financial_range_max, display_order) VALUES
(1, '極低', '影響極小，可忽略不計', 0, 10000, 1),
(2, '低', '影響輕微，容易恢復', 10001, 50000, 2),
(3, '中', '影響明顯，需要資源處理', 50001, 200000, 3),
(4, '高', '影響嚴重，業務受損', 200001, 1000000, 4),
(5, '極高', '影響重大，可能導致業務停擺', 1000001, 99999999, 5);

-- 可能性等級設定
INSERT INTO likelihood_levels (level_value, level_name, level_desc, probability_percentage, display_order) VALUES
(1, '極低', '幾乎不可能發生', '< 5%', 1),
(2, '低', '不太可能發生', '5% - 20%', 2),
(3, '中', '可能發生', '20% - 50%', 3),
(4, '高', '很可能發生', '50% - 80%', 4),
(5, '極高', '幾乎確定發生', '> 80%', 5);

-- 風險矩陣設定 (可能性 x 影響 = 風險等級)
INSERT INTO risk_matrix (likelihood_value, impact_value, risk_level, risk_score, color_code) VALUES
(1, 1, '極低', 1, '#00FF00'), (1, 2, '極低', 2, '#00FF00'), (1, 3, '低', 3, '#90EE90'),
(1, 4, '低', 4, '#FFFF00'), (1, 5, '中', 5, '#FFA500'),
(2, 1, '極低', 2, '#00FF00'), (2, 2, '低', 4, '#90EE90'), (2, 3, '低', 6, '#FFFF00'),
(2, 4, '中', 8, '#FFA500'), (2, 5, '高', 10, '#FF6347'),
(3, 1, '低', 3, '#90EE90'), (3, 2, '低', 6, '#FFFF00'), (3, 3, '中', 9, '#FFA500'),
(3, 4, '高', 12, '#FF6347'), (3, 5, '高', 15, '#FF0000'),
(4, 1, '低', 4, '#FFFF00'), (4, 2, '中', 8, '#FFA500'), (4, 3, '高', 12, '#FF6347'),
(4, 4, '高', 16, '#FF0000'), (4, 5, '極高', 20, '#8B0000'),
(5, 1, '中', 5, '#FFA500'), (5, 2, '高', 10, '#FF6347'), (5, 3, '高', 15, '#FF0000'),
(5, 4, '極高', 20, '#8B0000'), (5, 5, '極高', 25, '#8B0000');

-- 控制措施範例
INSERT INTO control_measures (control_code, control_name, control_desc, control_type, iso_annex_ref, 
    implementation_cost, annual_cost, effectiveness) VALUES
('CTL-001', '定期修補程式管理', '建立系統修補程式的定期檢查與更新機制', '預防性', 'A.8.8', 50000, 20000, 4),
('CTL-002', '強密碼政策實施', '要求複雜密碼並定期變更', '預防性', 'A.5.17', 10000, 5000, 4),
('CTL-003', '多因素認證(MFA)', '實施雙因素或多因素認證機制', '預防性', 'A.5.18', 80000, 30000, 5),
('CTL-004', '存取權限管理', '基於角色的存取控制(RBAC)', '預防性', 'A.5.15', 30000, 15000, 4),
('CTL-005', '資安教育訓練', '定期舉辦員工資訊安全意識訓練', '預防性', 'A.6.3', 40000, 40000, 3),
('CTL-006', '資料加密傳輸', '使用TLS/SSL加密所有敏感資料傳輸', '預防性', 'A.8.24', 60000, 20000, 5),
('CTL-007', '自動備份系統', '每日自動備份重要資料到異地', '矯正性', 'A.8.13', 100000, 50000, 5),
('CTL-008', '入侵偵測系統(IDS)', '部署IDS監控異常網路活動', '偵測性', 'A.8.16', 150000, 60000, 4),
('CTL-009', '防火牆規則管理', '定期檢視和更新防火牆規則', '預防性', 'A.8.20', 20000, 10000, 4),
('CTL-010', '日誌監控與分析', '集中收集和分析系統日誌', '偵測性', 'A.8.15', 80000, 40000, 4),
('CTL-011', '實體門禁管制', '機房實施刷卡門禁與監視系統', '預防性', 'A.7.2', 120000, 30000, 5),
('CTL-012', '業務持續計畫', '制定並定期演練BCP/DRP', '矯正性', 'A.5.29', 100000, 50000, 4),
('CTL-013', '供應商安全評估', '定期審查第三方供應商資安狀況', '預防性', 'A.5.19', 30000, 20000, 3),
('CTL-014', '網路區隔', '將網路劃分為不同安全區域', '預防性', 'A.8.20', 80000, 10000, 4),
('CTL-015', '防毒軟體部署', '所有終端設備安裝並更新防毒軟體', '預防性', 'A.8.7', 50000, 50000, 4);

-- 風險評估範例
INSERT INTO risk_assessments (assessment_code, asset_id, threat_id, vulnerability_id, 
    threat_likelihood, vulnerability_severity, impact_confidentiality, impact_integrity, 
    impact_availability, impact_financial, impact_reputation, impact_legal, 
    risk_level, risk_score, assessment_date, assessor, status) VALUES
('RA-2024-001', 1, 1, 1, 4, 3, 5, 4, 3, 500000, 5, 4, '高', 16, '2024-01-15', '王大明', '待處理'),
('RA-2024-002', 2, 2, 3, 3, 4, 5, 5, 4, 1000000, 5, 5, '高', 15, '2024-01-15', '王大明', '待處理'),
('RA-2024-003', 3, 7, 6, 2, 3, 4, 5, 5, 800000, 4, 3, '中', 8, '2024-01-16', '李小華', '處理中'),
('RA-2024-004', 5, 6, 5, 4, 4, 5, 4, 3, 2000000, 5, 5, '極高', 20, '2024-01-16', '王大明', '待處理'),
('RA-2024-005', 4, 5, 12, 3, 3, 2, 3, 5, 300000, 4, 2, '高', 12, '2024-01-17', '李小華', '待處理'),
('RA-2024-006', 6, 4, 4, 3, 4, 5, 5, 3, 1500000, 5, 4, '高', 15, '2024-01-17', '王大明', '處理中'),
('RA-2024-007', 8, 8, 8, 2, 2, 3, 3, 5, 500000, 3, 2, '中', 6, '2024-01-18', '張三', '已完成'),
('RA-2024-008', 1, 3, 4, 4, 5, 4, 3, 2, 400000, 4, 3, '高', 16, '2024-01-18', '李小華', '待處理');

-- 風險處理計畫範例
INSERT INTO risk_treatments (risk_assessment_id, treatment_strategy, control_measure_id, 
    residual_risk_level, residual_risk_score, implementation_priority, responsible_person, 
    target_date, status, cost_benefit_ratio, approval_status) VALUES
(1, '降低', 1, '中', 8, '高', '資訊部經理', '2024-03-31', '規劃中', 8.33, '已核准'),
(2, '降低', 3, '中', 9, '高', '資訊部經理', '2024-04-30', '規劃中', 12.50, '已核准'),
(3, '降低', 7, '低', 4, '中', '系統管理員', '2024-06-30', '執行中', 8.00, '已核准'),
(4, '降低', 6, '中', 10, '高', '資訊部經理', '2024-03-31', '規劃中', 33.33, '已核准'),
(5, '降低', 8, '低', 6, '高', '網管組長', '2024-05-31', '規劃中', 2.00, '待審核'),
(6, '降低', 5, '中', 9, '高', '人資部', '2024-02-28', '執行中', 37.50, '已核准'),
(7, '接受', NULL, '低', 6, '低', '總務部經理', NULL, '已完成', NULL, '已核准'),
(8, '降低', 5, '中', 8, '高', '人資部', '2024-02-28', '規劃中', 10.00, '已核准');

-- 風險監控記錄範例
INSERT INTO risk_monitoring (risk_assessment_id, monitoring_date, current_risk_level, 
    current_risk_score, control_effectiveness, incidents_occurred, monitoring_notes, monitor_by) VALUES
(7, '2024-01-25', '低', 6, 4, 0, '機房實體安全控制運作正常，無異常事件', '張三'),
(3, '2024-02-01', '中', 8, 3, 0, '備份系統正常運作，但需加強備份測試', '李小華'),
(6, '2024-02-05', '高', 12, 2, 1, '發現一起員工誤傳檔案事件，已加強教育訓練', '王大明')