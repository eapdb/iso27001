<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * Excel 報表匯出功能
 */
require_once 'config.php';

// 設定匯出檔案名稱
$filename = 'ISO27001_風險評估報表_' . date('Y-m-d') . '.xls';

// 設定 HTTP 標頭以匯出 Excel
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// 輸出 UTF-8 BOM，確保中文正確顯示
echo "\xEF\xBB\xBF";

// 取得所有需要的資料
$stats = [
    'total_assets' => fetchOne("SELECT COUNT(*) as count FROM assets")['count'],
    'total_risks' => fetchOne("SELECT COUNT(*) as count FROM risk_assessments")['count'],
    'high_risks' => fetchOne("SELECT COUNT(*) as count FROM risk_assessments WHERE risk_level IN ('高', '極高')")['count'],
    'total_treatments' => fetchOne("SELECT COUNT(*) as count FROM risk_treatments")['count'],
];

$risk_assessments = fetchAll("
    SELECT ra.*, 
           a.asset_code, a.asset_name, ac.category_name,
           t.threat_name,
           v.vulnerability_name
    FROM risk_assessments ra
    JOIN assets a ON ra.asset_id = a.id
    LEFT JOIN asset_categories ac ON a.category_id = ac.id
    JOIN threat_types t ON ra.threat_id = t.id
    LEFT JOIN vulnerabilities v ON ra.vulnerability_id = v.id
    ORDER BY ra.risk_score DESC, ra.created_at DESC
");

$assets = fetchAll("
    SELECT a.*, ac.category_name,
           (SELECT COUNT(*) FROM risk_assessments WHERE asset_id = a.id) as risk_count,
           (SELECT COUNT(*) FROM risk_assessments WHERE asset_id = a.id AND risk_level IN ('高', '極高')) as high_risk_count
    FROM assets a
    LEFT JOIN asset_categories ac ON a.category_id = ac.id
    ORDER BY a.asset_code
");

$treatments = fetchAll("
    SELECT rt.*, 
           ra.assessment_code, ra.risk_level, ra.risk_score,
           a.asset_name,
           cm.control_name, cm.implementation_cost, cm.annual_cost
    FROM risk_treatments rt
    JOIN risk_assessments ra ON rt.risk_assessment_id = ra.id
    JOIN assets a ON ra.asset_id = a.id
    LEFT JOIN control_measures cm ON rt.control_measure_id = cm.id
    ORDER BY rt.created_at DESC
");

$risk_distribution = fetchAll("
    SELECT risk_level, COUNT(*) as count 
    FROM risk_assessments 
    GROUP BY risk_level 
    ORDER BY FIELD(risk_level, '極低', '低', '中', '高', '極高')
");

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ISO 27001:2022 風險評估報表</title>
    <style>
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #667eea; color: white; font-weight: bold; }
        .section-title { 
            background-color: #f0f0f0; 
            font-size: 16px; 
            font-weight: bold; 
            padding: 10px; 
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .stat-table td { font-size: 14px; }
        .highlight { background-color: #fff3cd; }
        .danger { background-color: #f8d7da; color: #721c24; font-weight: bold; }
        .success { background-color: #d4edda; color: #155724; }
        .warning { background-color: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <h1 style="text-align: center; color: #667eea;">ISO 27001:2022 風險評估與管理報表</h1>
    <p style="text-align: center;">報表產生日期：<?php echo date('Y年m月d日 H:i:s'); ?></p>
    <p style="text-align: center;">組織名稱：<?php echo getSystemConfig('company_name'); ?></p>
    
    <div class="section-title">📊 綜合統計摘要</div>
    <table class="stat-table">
        <tr>
            <th>統計項目</th>
            <th>數量</th>
        </tr>
        <tr>
            <td>總資產數量</td>
            <td><?php echo $stats['total_assets']; ?></td>
        </tr>
        <tr>
            <td>風險評估總數</td>
            <td><?php echo $stats['total_risks']; ?></td>
        </tr>
        <tr class="danger">
            <td>高風險項目</td>
            <td><?php echo $stats['high_risks']; ?></td>
        </tr>
        <tr>
            <td>風險處理計畫數</td>
            <td><?php echo $stats['total_treatments']; ?></td>
        </tr>
    </table>
    
    <div class="section-title">📈 風險等級分布</div>
    <table>
        <tr>
            <th>風險等級</th>
            <th>數量</th>
            <th>百分比</th>
        </tr>
        <?php 
        $total = array_sum(array_column($risk_distribution, 'count'));
        foreach ($risk_distribution as $item): 
            $percentage = $total > 0 ? round(($item['count'] / $total) * 100, 1) : 0;
            $class = in_array($item['risk_level'], ['高', '極高']) ? 'danger' : '';
        ?>
        <tr class="<?php echo $class; ?>">
            <td><?php echo $item['risk_level']; ?></td>
            <td><?php echo $item['count']; ?></td>
            <td><?php echo $percentage; ?>%</td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <div class="section-title">📦 資產清單</div>
    <table>
        <tr>
            <th>資產編號</th>
            <th>資產名稱</th>
            <th>類別</th>
            <th>負責人</th>
            <th>位置</th>
            <th>機密性</th>
            <th>完整性</th>
            <th>可用性</th>
            <th>業務價值</th>
            <th>風險數</th>
            <th>高風險數</th>
        </tr>
        <?php foreach ($assets as $asset): 
            $class = $asset['high_risk_count'] > 0 ? 'danger' : '';
        ?>
        <tr class="<?php echo $class; ?>">
            <td><?php echo htmlspecialchars($asset['asset_code']); ?></td>
            <td><?php echo htmlspecialchars($asset['asset_name']); ?></td>
            <td><?php echo htmlspecialchars($asset['category_name']); ?></td>
            <td><?php echo htmlspecialchars($asset['owner']); ?></td>
            <td><?php echo htmlspecialchars($asset['location']); ?></td>
            <td><?php echo $asset['confidentiality_value']; ?></td>
            <td><?php echo $asset['integrity_value']; ?></td>
            <td><?php echo $asset['availability_value']; ?></td>
            <td><?php echo $asset['business_value']; ?></td>
            <td><?php echo $asset['risk_count']; ?></td>
            <td><?php echo $asset['high_risk_count']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <div class="section-title">⚠️ 風險評估清單</div>
    <table>
        <tr>
            <th>評估編號</th>
            <th>資產編號</th>
            <th>資產名稱</th>
            <th>類別</th>
            <th>威脅</th>
            <th>漏洞</th>
            <th>威脅可能性</th>
            <th>漏洞嚴重度</th>
            <th>機密性影響</th>
            <th>完整性影響</th>
            <th>可用性影響</th>
            <th>財務影響</th>
            <th>風險分數</th>
            <th>風險等級</th>
            <th>評估日期</th>
            <th>評估人</th>
            <th>狀態</th>
        </tr>
        <?php foreach ($risk_assessments as $ra): 
            $class = in_array($ra['risk_level'], ['高', '極高']) ? 'danger' : 
                    ($ra['risk_level'] == '中' ? 'warning' : '');
        ?>
        <tr class="<?php echo $class; ?>">
            <td><?php echo htmlspecialchars($ra['assessment_code']); ?></td>
            <td><?php echo htmlspecialchars($ra['asset_code']); ?></td>
            <td><?php echo htmlspecialchars($ra['asset_name']); ?></td>
            <td><?php echo htmlspecialchars($ra['category_name']); ?></td>
            <td><?php echo htmlspecialchars($ra['threat_name']); ?></td>
            <td><?php echo htmlspecialchars($ra['vulnerability_name']); ?></td>
            <td><?php echo $ra['threat_likelihood']; ?></td>
            <td><?php echo $ra['vulnerability_severity']; ?></td>
            <td><?php echo $ra['impact_confidentiality']; ?></td>
            <td><?php echo $ra['impact_integrity']; ?></td>
            <td><?php echo $ra['impact_availability']; ?></td>
            <td>$<?php echo number_format($ra['impact_financial']); ?></td>
            <td><?php echo $ra['risk_score']; ?></td>
            <td><?php echo $ra['risk_level']; ?></td>
            <td><?php echo $ra['assessment_date']; ?></td>
            <td><?php echo htmlspecialchars($ra['assessor']); ?></td>
            <td><?php echo htmlspecialchars($ra['status']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <div class="section-title">🛡️ 風險處理計畫</div>
    <table>
        <tr>
            <th>評估編號</th>
            <th>資產名稱</th>
            <th>原風險等級</th>
            <th>原風險分數</th>
            <th>處理策略</th>
            <th>控制措施</th>
            <th>實施成本</th>
            <th>年度成本</th>
            <th>殘餘風險等級</th>
            <th>殘餘風險分數</th>
            <th>成本效益比</th>
            <th>優先順序</th>
            <th>負責人</th>
            <th>目標日期</th>
            <th>狀態</th>
        </tr>
        <?php foreach ($treatments as $treatment): 
            $class = $treatment['status'] == '已完成' ? 'success' : 
                    ($treatment['status'] == '規劃中' ? 'warning' : '');
        ?>
        <tr class="<?php echo $class; ?>">
            <td><?php echo htmlspecialchars($treatment['assessment_code']); ?></td>
            <td><?php echo htmlspecialchars($treatment['asset_name']); ?></td>
            <td><?php echo $treatment['risk_level']; ?></td>
            <td><?php echo $treatment['risk_score']; ?></td>
            <td><?php echo htmlspecialchars($treatment['treatment_strategy']); ?></td>
            <td><?php echo htmlspecialchars($treatment['control_name'] ?: '-'); ?></td>
            <td>$<?php echo number_format($treatment['implementation_cost']); ?></td>
            <td>$<?php echo number_format($treatment['annual_cost']); ?></td>
            <td><?php echo $treatment['residual_risk_level']; ?></td>
            <td><?php echo $treatment['residual_risk_score']; ?></td>
            <td><?php echo $treatment['cost_benefit_ratio'] ? number_format($treatment['cost_benefit_ratio'], 2) : '-'; ?></td>
            <td><?php echo htmlspecialchars($treatment['implementation_priority']); ?></td>
            <td><?php echo htmlspecialchars($treatment['responsible_person']); ?></td>
            <td><?php echo $treatment['target_date'] ?: '-'; ?></td>
            <td><?php echo htmlspecialchars($treatment['status']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <div class="section-title">📝 報表說明</div>
    <table>
        <tr>
            <th>項目</th>
            <th>說明</th>
        </tr>
        <tr>
            <td>風險評估方法</td>
            <td>基於 ISO 27001:2022 標準，採用可能性與影響矩陣法</td>
        </tr>
        <tr>
            <td>風險等級</td>
            <td>極低 / 低 / 中 / 高 / 極高（五級制）</td>
        </tr>
        <tr>
            <td>評估要素</td>
            <td>資產價值（CIA+B）、威脅可能性、漏洞嚴重度、業務影響</td>
        </tr>
        <tr>
            <td>處理策略</td>
            <td>降低、轉移、避免、接受</td>
        </tr>
        <tr>
            <td>成本效益比</td>
            <td>= (風險降低價值 - 實施總成本) / 實施總成本</td>
        </tr>
    </table>
    
    <p style="margin-top: 30px; text-align: center; color: #666;">
        本報表由 ISO 27001:2022 風險評估與管理系統自動產生<br>
        報表產生時間：<?php echo date('Y-m-d H:i:s'); ?>
    </p>
</body>
</html>