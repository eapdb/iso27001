<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 系統設定界面 - 管理可自訂的參數
 */
require_once 'config.php';

// 啟動 session 用於訊息傳遞
session_start();

// 檢查是否有來自重定向的訊息
$message = null;
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

// 處理表單提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_config':
                foreach ($_POST as $key => $value) {
                    if ($key !== 'action' && strpos($key, 'config_') === 0) {
                        $config_key = substr($key, 7);
                        executeQuery(
                            "UPDATE system_config SET config_value = ? WHERE config_key = ?",
                            [$value, $config_key]
                        );
                    }
                }
                $_SESSION['message'] = "系統設定已更新！";
                header("Location: settings.php?tab=0");
                exit;
                break;
                
            case 'add_category':
                $sql = "INSERT INTO asset_categories (category_name, category_desc, display_order) VALUES (?, ?, ?)";
                executeQuery($sql, [$_POST['category_name'], $_POST['category_desc'], $_POST['display_order']]);
                $_SESSION['message'] = "資產類別已新增！";
                header("Location: settings.php?tab=1");
                exit;
                break;
                
            case 'add_category':
                $sql = "INSERT INTO asset_categories (category_name, category_desc, display_order) VALUES (?, ?, ?)";
                executeQuery($sql, [$_POST['category_name'], $_POST['category_desc'], $_POST['display_order']]);
                $message = "資產類別已新增！";
                break;
                
            case 'add_category':
                $sql = "INSERT INTO asset_categories (category_name, category_desc, display_order) VALUES (?, ?, ?)";
                executeQuery($sql, [$_POST['category_name'], $_POST['category_desc'], $_POST['display_order']]);
                $_SESSION['message'] = "資產類別已新增！";
                header("Location: settings.php?tab=1");
                exit;
                break;
                
            case 'update_category':
                $sql = "UPDATE asset_categories SET category_name = ?, category_desc = ?, display_order = ?, is_active = ? WHERE id = ?";
                executeQuery($sql, [$_POST['category_name'], $_POST['category_desc'], $_POST['display_order'], $_POST['is_active'], $_POST['category_id']]);
                $_SESSION['message'] = "資產類別已更新！";
                header("Location: settings.php?tab=1");
                exit;
                break;
                
            case 'delete_category':
                executeQuery("DELETE FROM asset_categories WHERE id = ?", [$_POST['category_id']]);
                $_SESSION['message'] = "資產類別已刪除！";
                header("Location: settings.php?tab=1");
                exit;
                break;
                
            case 'add_threat':
                $sql = "INSERT INTO threat_types (threat_name, threat_desc, threat_category, display_order) VALUES (?, ?, ?, ?)";
                executeQuery($sql, [$_POST['threat_name'], $_POST['threat_desc'], $_POST['threat_category'], $_POST['display_order']]);
                $_SESSION['message'] = "威脅類型已新增！";
                header("Location: settings.php?tab=2");
                exit;
                break;
                
            case 'update_threat':
                $sql = "UPDATE threat_types SET threat_name = ?, threat_desc = ?, threat_category = ?, display_order = ?, is_active = ? WHERE id = ?";
                executeQuery($sql, [$_POST['threat_name'], $_POST['threat_desc'], $_POST['threat_category'], $_POST['display_order'], $_POST['is_active'], $_POST['threat_id']]);
                $_SESSION['message'] = "威脅類型已更新！";
                header("Location: settings.php?tab=2");
                exit;
                break;
                
            case 'delete_threat':
                executeQuery("DELETE FROM threat_types WHERE id = ?", [$_POST['threat_id']]);
                $_SESSION['message'] = "威脅類型已刪除！";
                header("Location: settings.php?tab=2");
                exit;
                break;
                
            case 'add_vulnerability':
                $sql = "INSERT INTO vulnerabilities (vulnerability_name, vulnerability_desc, vulnerability_type, ease_of_exploitation, display_order) VALUES (?, ?, ?, ?, ?)";
                executeQuery($sql, [$_POST['vulnerability_name'], $_POST['vulnerability_desc'], $_POST['vulnerability_type'], $_POST['ease_of_exploitation'], $_POST['display_order']]);
                $_SESSION['message'] = "漏洞已新增！";
                header("Location: settings.php?tab=3");
                exit;
                break;
                
            case 'update_vulnerability':
                $sql = "UPDATE vulnerabilities SET vulnerability_name = ?, vulnerability_desc = ?, vulnerability_type = ?, ease_of_exploitation = ?, display_order = ?, is_active = ? WHERE id = ?";
                executeQuery($sql, [$_POST['vulnerability_name'], $_POST['vulnerability_desc'], $_POST['vulnerability_type'], $_POST['ease_of_exploitation'], $_POST['display_order'], $_POST['is_active'], $_POST['vuln_id']]);
                $_SESSION['message'] = "漏洞已更新！";
                header("Location: settings.php?tab=3");
                exit;
                break;
                
            case 'delete_vulnerability':
                executeQuery("DELETE FROM vulnerabilities WHERE id = ?", [$_POST['vuln_id']]);
                $_SESSION['message'] = "漏洞已刪除！";
                header("Location: settings.php?tab=3");
                exit;
                break;
                
            case 'add_control':
                $sql = "INSERT INTO control_measures (control_code, control_name, control_desc, control_type, iso_annex_ref, implementation_cost, annual_cost, effectiveness) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $control_code = 'CTL-' . str_pad(fetchOne("SELECT COUNT(*) + 1 as next FROM control_measures")['next'], 3, '0', STR_PAD_LEFT);
                executeQuery($sql, [
                    $control_code, $_POST['control_name'], $_POST['control_desc'], 
                    $_POST['control_type'], $_POST['iso_annex_ref'],
                    $_POST['implementation_cost'], $_POST['annual_cost'], $_POST['effectiveness']
                ]);
                $_SESSION['message'] = "控制措施已新增！編號: {$control_code}";
                header("Location: settings.php?tab=4");
                exit;
                break;
                
            case 'update_control':
                $sql = "UPDATE control_measures SET control_name = ?, control_desc = ?, control_type = ?, iso_annex_ref = ?, implementation_cost = ?, annual_cost = ?, effectiveness = ?, is_active = ? WHERE id = ?";
                executeQuery($sql, [
                    $_POST['control_name'], $_POST['control_desc'], 
                    $_POST['control_type'], $_POST['iso_annex_ref'],
                    $_POST['implementation_cost'], $_POST['annual_cost'], $_POST['effectiveness'],
                    $_POST['is_active'], $_POST['control_id']
                ]);
                $_SESSION['message'] = "控制措施已更新！";
                header("Location: settings.php?tab=4");
                exit;
                break;
                
            case 'delete_control':
                executeQuery("DELETE FROM control_measures WHERE id = ?", [$_POST['control_id']]);
                $message = "控制措施已刪除！";
                header("Location: settings.php?tab=4");
                exit;
                break;
        }
    }
}

// 取得系統設定
$system_configs = fetchAll("SELECT * FROM system_config ORDER BY id");

// 取得各項基礎資料
$categories = fetchAll("SELECT * FROM asset_categories ORDER BY display_order");
$threats = fetchAll("SELECT * FROM threat_types ORDER BY display_order");
$vulnerabilities = fetchAll("SELECT * FROM vulnerabilities ORDER BY display_order");
$controls = fetchAll("SELECT * FROM control_measures ORDER BY control_code");

// 取得編輯項目（檢查URL參數）
$edit_category = isset($_GET['edit_cat']) ? fetchOne("SELECT * FROM asset_categories WHERE id = ?", [$_GET['edit_cat']]) : null;
$edit_threat = isset($_GET['edit_threat']) ? fetchOne("SELECT * FROM threat_types WHERE id = ?", [$_GET['edit_threat']]) : null;
$edit_vuln = isset($_GET['edit_vuln']) ? fetchOne("SELECT * FROM vulnerabilities WHERE id = ?", [$_GET['edit_vuln']]) : null;
$edit_control = isset($_GET['edit_control']) ? fetchOne("SELECT * FROM control_measures WHERE id = ?", [$_GET['edit_control']]) : null;
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系統設定 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a { color: white; text-decoration: none; margin-right: 1.5rem; font-weight: 500; }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #dee2e6;
            flex-wrap: wrap;
        }
        .tab {
            padding: 0.8rem 1.5rem;
            background: white;
            border: none;
            cursor: pointer;
            font-size: 0.95rem;
            border-radius: 5px 5px 0 0;
            transition: background 0.3s;
        }
        .tab.active { background: #667eea; color: white; font-weight: 600; }
        .tab:hover:not(.active) { background: #f8f9fa; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        .card h2 {
            font-size: 1.4rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
            font-size: 0.95rem;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            font-family: inherit;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 5px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
            <a href="settings.php">系統設定</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($message)): ?>
        <div class="alert">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab(0)">⚙️ 系統參數</button>
            <button class="tab" onclick="switchTab(1)">📁 資產類別</button>
            <button class="tab" onclick="switchTab(2)">⚠️ 威脅類型</button>
            <button class="tab" onclick="switchTab(3)">🔓 漏洞管理</button>
            <button class="tab" onclick="switchTab(4)">🛡️ 控制措施</button>
        </div>
        
        <!-- Tab 0: 系統參數 -->
        <div class="tab-content active">
            <div class="card">
                <h2>⚙️ 系統參數設定</h2>
                <div class="info-box">
                    這些參數會影響風險評估的計算和顯示方式
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="update_config">
                    <div class="form-grid">
                        <?php foreach ($system_configs as $config): ?>
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($config['config_desc']); ?></label>
                            <input type="text" name="config_<?php echo $config['config_key']; ?>" 
                                   value="<?php echo htmlspecialchars($config['config_value']); ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div style="margin-top: 2rem;">
                        <button type="submit" class="btn">💾 儲存設定</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tab 1: 資產類別 -->
        <div class="tab-content">
            <div class="card">
                <h2><?php echo $edit_category ? '✏️ 編輯資產類別' : '➕ 新增資產類別'; ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="<?php echo $edit_category ? 'update_category' : 'add_category'; ?>">
                    <?php if ($edit_category): ?>
                    <input type="hidden" name="category_id" value="<?php echo $edit_category['id']; ?>">
                    <?php endif; ?>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>類別名稱 *</label>
                            <input type="text" name="category_name" required
                                   value="<?php echo $edit_category ? htmlspecialchars($edit_category['category_name']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" 
                                   value="<?php echo $edit_category ? $edit_category['display_order'] : '0'; ?>">
                        </div>
                        <?php if ($edit_category): ?>
                        <div class="form-group">
                            <label>狀態</label>
                            <select name="is_active">
                                <option value="1" <?php echo $edit_category['is_active'] ? 'selected' : ''; ?>>啟用</option>
                                <option value="0" <?php echo !$edit_category['is_active'] ? 'selected' : ''; ?>>停用</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>類別說明</label>
                        <textarea name="category_desc" rows="2"><?php echo $edit_category ? htmlspecialchars($edit_category['category_desc']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-success"><?php echo $edit_category ? '更新類別' : '新增類別'; ?></button>
                        <?php if ($edit_category): ?>
                        <a href="settings.php?tab=1" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有資產類別</h2>
                <table>
                    <thead>
                        <tr>
                            <th>類別名稱</th>
                            <th>說明</th>
                            <th>顯示順序</th>
                            <th>狀態</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($cat['category_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($cat['category_desc']); ?></td>
                            <td><?php echo $cat['display_order']; ?></td>
                            <td>
                                <span class="badge <?php echo $cat['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $cat['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?tab=1&edit_cat=<?php echo $cat['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此類別嗎？');">
                                        <input type="hidden" name="action" value="delete_category">
                                        <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                        <button type="submit" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem; background: #dc3545;">刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 1: 資產類別 -->
        <div class="tab-content">
            <div class="card">
                <h2><?php echo $edit_category ? '✏️ 編輯資產類別' : '➕ 新增資產類別'; ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="<?php echo $edit_category ? 'update_category' : 'add_category'; ?>">
                    <?php if ($edit_category): ?>
                    <input type="hidden" name="category_id" value="<?php echo $edit_category['id']; ?>">
                    <?php endif; ?>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>類別名稱 *</label>
                            <input type="text" name="category_name" required
                                   value="<?php echo $edit_category ? htmlspecialchars($edit_category['category_name']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" 
                                   value="<?php echo $edit_category ? $edit_category['display_order'] : '0'; ?>">
                        </div>
                        <?php if ($edit_category): ?>
                        <div class="form-group">
                            <label>狀態</label>
                            <select name="is_active">
                                <option value="1" <?php echo $edit_category['is_active'] ? 'selected' : ''; ?>>啟用</option>
                                <option value="0" <?php echo !$edit_category['is_active'] ? 'selected' : ''; ?>>停用</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>類別說明</label>
                        <textarea name="category_desc" rows="2"><?php echo $edit_category ? htmlspecialchars($edit_category['category_desc']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-success"><?php echo $edit_category ? '更新類別' : '新增類別'; ?></button>
                        <?php if ($edit_category): ?>
                        <a href="settings.php?tab=1" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有資產類別</h2>
                <table>
                    <thead>
                        <tr>
                            <th>類別名稱</th>
                            <th>說明</th>
                            <th>顯示順序</th>
                            <th>狀態</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($cat['category_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($cat['category_desc']); ?></td>
                            <td><?php echo $cat['display_order']; ?></td>
                            <td>
                                <span class="badge <?php echo $cat['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $cat['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?tab=1&edit_cat=<?php echo $cat['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此類別嗎？');">
                                        <input type="hidden" name="action" value="delete_category">
                                        <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                        <button type="submit" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem; background: #dc3545;">刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 2: 威脅類型 -->
        <div class="tab-content">
            <div class="card">
                <h2><?php echo $edit_threat ? '✏️ 編輯威脅類型' : '➕ 新增威脅類型'; ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="<?php echo $edit_threat ? 'update_threat' : 'add_threat'; ?>">
                    <?php if ($edit_threat): ?>
                    <input type="hidden" name="threat_id" value="<?php echo $edit_threat['id']; ?>">
                    <?php endif; ?>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>威脅名稱 *</label>
                            <input type="text" name="threat_name" required
                                   value="<?php echo $edit_threat ? htmlspecialchars($edit_threat['threat_name']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>威脅類別</label>
                            <select name="threat_category">
                                <option value="技術威脅" <?php echo ($edit_threat && $edit_threat['threat_category'] == '技術威脅') ? 'selected' : ''; ?>>技術威脅</option>
                                <option value="人為威脅" <?php echo ($edit_threat && $edit_threat['threat_category'] == '人為威脅') ? 'selected' : ''; ?>>人為威脅</option>
                                <option value="環境威脅" <?php echo ($edit_threat && $edit_threat['threat_category'] == '環境威脅') ? 'selected' : ''; ?>>環境威脅</option>
                                <option value="外部威脅" <?php echo ($edit_threat && $edit_threat['threat_category'] == '外部威脅') ? 'selected' : ''; ?>>外部威脅</option>
                                <option value="法律威脅" <?php echo ($edit_threat && $edit_threat['threat_category'] == '法律威脅') ? 'selected' : ''; ?>>法律威脅</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" 
                                   value="<?php echo $edit_threat ? $edit_threat['display_order'] : '0'; ?>">
                        </div>
                        <?php if ($edit_threat): ?>
                        <div class="form-group">
                            <label>狀態</label>
                            <select name="is_active">
                                <option value="1" <?php echo $edit_threat['is_active'] ? 'selected' : ''; ?>>啟用</option>
                                <option value="0" <?php echo !$edit_threat['is_active'] ? 'selected' : ''; ?>>停用</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>威脅說明</label>
                        <textarea name="threat_desc" rows="2"><?php echo $edit_threat ? htmlspecialchars($edit_threat['threat_desc']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-success"><?php echo $edit_threat ? '更新威脅' : '新增威脅'; ?></button>
                        <?php if ($edit_threat): ?>
                        <a href="settings.php?tab=2" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有威脅類型</h2>
                <table>
                    <thead>
                        <tr>
                            <th>威脅名稱</th>
                            <th>類別</th>
                            <th>說明</th>
                            <th>狀態</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($threats as $threat): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($threat['threat_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($threat['threat_category']); ?></td>
                            <td><?php echo htmlspecialchars($threat['threat_desc']); ?></td>
                            <td>
                                <span class="badge <?php echo $threat['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $threat['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?tab=2&edit_threat=<?php echo $threat['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此威脅類型嗎？');">
                                        <input type="hidden" name="action" value="delete_threat">
                                        <input type="hidden" name="threat_id" value="<?php echo $threat['id']; ?>">
                                        <button type="submit" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem; background: #dc3545;">刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 3: 漏洞管理 -->
        <div class="tab-content">
            <div class="card">
                <h2><?php echo $edit_vuln ? '✏️ 編輯漏洞' : '➕ 新增漏洞'; ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="<?php echo $edit_vuln ? 'update_vulnerability' : 'add_vulnerability'; ?>">
                    <?php if ($edit_vuln): ?>
                    <input type="hidden" name="vuln_id" value="<?php echo $edit_vuln['id']; ?>">
                    <?php endif; ?>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>漏洞名稱 *</label>
                            <input type="text" name="vulnerability_name" required
                                   value="<?php echo $edit_vuln ? htmlspecialchars($edit_vuln['vulnerability_name']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>漏洞類型</label>
                            <select name="vulnerability_type">
                                <option value="技術漏洞" <?php echo ($edit_vuln && $edit_vuln['vulnerability_type'] == '技術漏洞') ? 'selected' : ''; ?>>技術漏洞</option>
                                <option value="管理漏洞" <?php echo ($edit_vuln && $edit_vuln['vulnerability_type'] == '管理漏洞') ? 'selected' : ''; ?>>管理漏洞</option>
                                <option value="人為漏洞" <?php echo ($edit_vuln && $edit_vuln['vulnerability_type'] == '人為漏洞') ? 'selected' : ''; ?>>人為漏洞</option>
                                <option value="實體漏洞" <?php echo ($edit_vuln && $edit_vuln['vulnerability_type'] == '實體漏洞') ? 'selected' : ''; ?>>實體漏洞</option>
                                <option value="架構漏洞" <?php echo ($edit_vuln && $edit_vuln['vulnerability_type'] == '架構漏洞') ? 'selected' : ''; ?>>架構漏洞</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>利用難度 (1-5)</label>
                            <select name="ease_of_exploitation">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($edit_vuln && $edit_vuln['ease_of_exploitation'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>顯示順序</label>
                            <input type="number" name="display_order" 
                                   value="<?php echo $edit_vuln ? $edit_vuln['display_order'] : '0'; ?>">
                        </div>
                        <?php if ($edit_vuln): ?>
                        <div class="form-group">
                            <label>狀態</label>
                            <select name="is_active">
                                <option value="1" <?php echo $edit_vuln['is_active'] ? 'selected' : ''; ?>>啟用</option>
                                <option value="0" <?php echo !$edit_vuln['is_active'] ? 'selected' : ''; ?>>停用</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>漏洞說明</label>
                        <textarea name="vulnerability_desc" rows="2"><?php echo $edit_vuln ? htmlspecialchars($edit_vuln['vulnerability_desc']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-success"><?php echo $edit_vuln ? '更新漏洞' : '新增漏洞'; ?></button>
                        <?php if ($edit_vuln): ?>
                        <a href="settings.php?tab=3" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有漏洞</h2>
                <table>
                    <thead>
                        <tr>
                            <th>漏洞名稱</th>
                            <th>類型</th>
                            <th>利用難度</th>
                            <th>說明</th>
                            <th>狀態</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vulnerabilities as $vuln): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($vuln['vulnerability_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($vuln['vulnerability_type']); ?></td>
                            <td><?php echo $vuln['ease_of_exploitation']; ?>/5</td>
                            <td><?php echo htmlspecialchars($vuln['vulnerability_desc']); ?></td>
                            <td>
                                <span class="badge <?php echo $vuln['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $vuln['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?tab=3&edit_vuln=<?php echo $vuln['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此漏洞嗎？');">
                                        <input type="hidden" name="action" value="delete_vulnerability">
                                        <input type="hidden" name="vuln_id" value="<?php echo $vuln['id']; ?>">
                                        <button type="submit" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem; background: #dc3545;">刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tab 4: 控制措施 -->
        <div class="tab-content">
            <div class="card">
                <h2><?php echo $edit_control ? '✏️ 編輯控制措施' : '➕ 新增控制措施'; ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="<?php echo $edit_control ? 'update_control' : 'add_control'; ?>">
                    <?php if ($edit_control): ?>
                    <input type="hidden" name="control_id" value="<?php echo $edit_control['id']; ?>">
                    <?php endif; ?>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>控制措施名稱 *</label>
                            <input type="text" name="control_name" required
                                   value="<?php echo $edit_control ? htmlspecialchars($edit_control['control_name']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>控制類型</label>
                            <select name="control_type">
                                <option value="預防性" <?php echo ($edit_control && $edit_control['control_type'] == '預防性') ? 'selected' : ''; ?>>預防性</option>
                                <option value="偵測性" <?php echo ($edit_control && $edit_control['control_type'] == '偵測性') ? 'selected' : ''; ?>>偵測性</option>
                                <option value="矯正性" <?php echo ($edit_control && $edit_control['control_type'] == '矯正性') ? 'selected' : ''; ?>>矯正性</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>ISO 27001 附錄A參考</label>
                            <input type="text" name="iso_annex_ref" placeholder="例如: A.8.8"
                                   value="<?php echo $edit_control ? htmlspecialchars($edit_control['iso_annex_ref']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>實施成本 (TWD)</label>
                            <input type="number" name="implementation_cost" step="0.01"
                                   value="<?php echo $edit_control ? $edit_control['implementation_cost'] : '0'; ?>">
                        </div>
                        <div class="form-group">
                            <label>年度維護成本 (TWD)</label>
                            <input type="number" name="annual_cost" step="0.01"
                                   value="<?php echo $edit_control ? $edit_control['annual_cost'] : '0'; ?>">
                        </div>
                        <div class="form-group">
                            <label>有效性 (1-5)</label>
                            <select name="effectiveness">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($edit_control && $edit_control['effectiveness'] == $i) ? 'selected' : ((!$edit_control && $i == 3) ? 'selected' : ''); ?>><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <?php if ($edit_control): ?>
                        <div class="form-group">
                            <label>狀態</label>
                            <select name="is_active">
                                <option value="1" <?php echo $edit_control['is_active'] ? 'selected' : ''; ?>>啟用</option>
                                <option value="0" <?php echo !$edit_control['is_active'] ? 'selected' : ''; ?>>停用</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>控制措施說明</label>
                        <textarea name="control_desc" rows="3"><?php echo $edit_control ? htmlspecialchars($edit_control['control_desc']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-success"><?php echo $edit_control ? '更新控制措施' : '新增控制措施'; ?></button>
                        <?php if ($edit_control): ?>
                        <a href="settings.php?tab=4" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card">
                <h2>📋 現有控制措施</h2>
                <table>
                    <thead>
                        <tr>
                            <th>編號</th>
                            <th>名稱</th>
                            <th>類型</th>
                            <th>ISO參考</th>
                            <th>實施成本</th>
                            <th>年度成本</th>
                            <th>有效性</th>
                            <th>狀態</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($controls as $control): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($control['control_code']); ?></strong></td>
                            <td><?php echo htmlspecialchars($control['control_name']); ?></td>
                            <td><?php echo htmlspecialchars($control['control_type']); ?></td>
                            <td><?php echo htmlspecialchars($control['iso_annex_ref']); ?></td>
                            <td>$<?php echo number_format($control['implementation_cost']); ?></td>
                            <td>$<?php echo number_format($control['annual_cost']); ?></td>
                            <td><?php echo $control['effectiveness']; ?>/5</td>
                            <td>
                                <span class="badge <?php echo $control['is_active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $control['is_active'] ? '啟用' : '停用'; ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?tab=4&edit_control=<?php echo $control['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此控制措施嗎？');">
                                        <input type="hidden" name="action" value="delete_control">
                                        <input type="hidden" name="control_id" value="<?php echo $control['id']; ?>">
                                        <button type="submit" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem; background: #dc3545;">刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function switchTab(index) {
            const tabs = document.querySelectorAll('.tab');
            const contents = document.querySelectorAll('.tab-content');
            
            tabs.forEach((tab, i) => {
                if (i === index) {
                    tab.classList.add('active');
                    contents[i].classList.add('active');
                } else {
                    tab.classList.remove('active');
                    contents[i].classList.remove('active');
                }
            });
        }
        
        // 頁面載入時根據URL參數切換到對應Tab
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const tabIndex = urlParams.get('tab');
            if (tabIndex) {
                switchTab(parseInt(tabIndex));
            }
        };
    </script>
</body>
</html>