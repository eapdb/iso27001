<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 風險處理計畫 - Part 1
 */
require_once 'config.php';
session_start();

$message = null;
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

// 處理表單提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete_treatment') {
        executeQuery("DELETE FROM risk_treatments WHERE id = ?", [$_POST['treatment_id']]);
        executeQuery("UPDATE risk_assessments SET status = '待處理' WHERE id = ?", [$_POST['risk_assessment_id']]);
        $_SESSION['message'] = "風險處理計畫已刪除！";
        header("Location: risk_treatment.php");
        exit;
    } elseif ($_POST['action'] === 'update_treatment') {
        $risk_assessment = fetchOne("SELECT * FROM risk_assessments WHERE id = ?", [$_POST['risk_assessment_id']]);
        $cost_benefit_ratio = 0;
        if ($_POST['treatment_strategy'] === '降低' && $_POST['control_measure_id']) {
            $control = fetchOne("SELECT * FROM control_measures WHERE id = ?", [$_POST['control_measure_id']]);
            $total_cost = $control['implementation_cost'] + ($control['annual_cost'] * 3);
            $risk_value = $risk_assessment['risk_score'] * 100000;
            $cost_benefit_ratio = $total_cost > 0 ? ($risk_value - $total_cost) / $total_cost : 0;
        }
        $sql = "UPDATE risk_treatments SET treatment_strategy = ?, control_measure_id = ?, residual_risk_level = ?, residual_risk_score = ?, implementation_priority = ?, responsible_person = ?, target_date = ?, status = ?, cost_benefit_ratio = ?, notes = ? WHERE id = ?";
        executeQuery($sql, [$_POST['treatment_strategy'], $_POST['control_measure_id'] ?: null, $_POST['residual_risk_level'], $_POST['residual_risk_score'], $_POST['implementation_priority'], $_POST['responsible_person'], $_POST['target_date'] ?: null, $_POST['status'], $cost_benefit_ratio, $_POST['notes'], $_POST['treatment_id']]);
        $_SESSION['message'] = "風險處理計畫已更新！";
        header("Location: risk_treatment.php");
        exit;
    } elseif ($_POST['action'] === 'save_treatment') {
        $risk_assessment = fetchOne("SELECT * FROM risk_assessments WHERE id = ?", [$_POST['risk_assessment_id']]);
        $cost_benefit_ratio = 0;
        if ($_POST['treatment_strategy'] === '降低' && $_POST['control_measure_id']) {
            $control = fetchOne("SELECT * FROM control_measures WHERE id = ?", [$_POST['control_measure_id']]);
            $total_cost = $control['implementation_cost'] + ($control['annual_cost'] * 3);
            $risk_value = $risk_assessment['risk_score'] * 100000;
            $cost_benefit_ratio = $total_cost > 0 ? ($risk_value - $total_cost) / $total_cost : 0;
        }
        $sql = "INSERT INTO risk_treatments (risk_assessment_id, treatment_strategy, control_measure_id, residual_risk_level, residual_risk_score, implementation_priority, responsible_person, target_date, status, cost_benefit_ratio, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        executeQuery($sql, [$_POST['risk_assessment_id'], $_POST['treatment_strategy'], $_POST['control_measure_id'] ?: null, $_POST['residual_risk_level'], $_POST['residual_risk_score'], $_POST['implementation_priority'], $_POST['responsible_person'], $_POST['target_date'] ?: null, '規劃中', $cost_benefit_ratio, $_POST['notes']]);
        executeQuery("UPDATE risk_assessments SET status = '處理中' WHERE id = ?", [$_POST['risk_assessment_id']]);
        $_SESSION['message'] = "風險處理計畫已建立！";
        header("Location: risk_treatment.php");
        exit;
    }
}

$pending_risks = fetchAll("SELECT ra.*, a.asset_name, t.threat_name FROM risk_assessments ra JOIN assets a ON ra.asset_id = a.id JOIN threat_types t ON ra.threat_id = t.id WHERE ra.status IN ('待處理', '處理中') ORDER BY ra.risk_score DESC");
$control_measures = fetchAll("SELECT * FROM control_measures WHERE is_active = 1 ORDER BY effectiveness DESC, implementation_cost ASC");
$treatments = fetchAll("SELECT rt.*, ra.assessment_code, ra.risk_level, ra.risk_score, ra.id as risk_assessment_id, a.asset_name, cm.control_name, cm.implementation_cost, cm.annual_cost FROM risk_treatments rt JOIN risk_assessments ra ON rt.risk_assessment_id = ra.id JOIN assets a ON ra.asset_id = a.id LEFT JOIN control_measures cm ON rt.control_measure_id = cm.id ORDER BY rt.created_at DESC");
$selected_risk = null;
if (isset($_GET['risk_id'])) {
    $selected_risk = fetchOne("SELECT ra.*, a.asset_name, t.threat_name, v.vulnerability_name FROM risk_assessments ra JOIN assets a ON ra.asset_id = a.id JOIN threat_types t ON ra.threat_id = t.id LEFT JOIN vulnerabilities v ON ra.vulnerability_id = v.id WHERE ra.id = ?", [$_GET['risk_id']]);
}
$edit_treatment = null;
if (isset($_GET['edit_id'])) {
    $edit_treatment = fetchOne("SELECT rt.*, ra.id as risk_assessment_id, ra.assessment_code, ra.risk_score, a.asset_name, t.threat_name FROM risk_treatments rt JOIN risk_assessments ra ON rt.risk_assessment_id = ra.id JOIN assets a ON ra.asset_id = a.id JOIN threat_types t ON ra.threat_id = t.id WHERE rt.id = ?", [$_GET['edit_id']]);
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>風險處理 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        .navbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1rem 2rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a { color: white; text-decoration: none; margin-right: 1.5rem; font-weight: 500; }
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: 5px; background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .tabs { display: flex; gap: 0.5rem; margin-bottom: 2rem; border-bottom: 2px solid #dee2e6; }
        .tab { padding: 0.8rem 1.5rem; background: white; border: none; cursor: pointer; font-size: 1rem; border-radius: 5px 5px 0 0; }
        .tab.active { background: #667eea; color: white; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .card { background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 2rem; }
        .card h2 { font-size: 1.4rem; margin-bottom: 1.5rem; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 0.5rem; }
        .risk-summary { background: linear-gradient(135deg, #667eea15, #764ba215); padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem; border-left: 5px solid #667eea; }
        .risk-summary h3 { margin-bottom: 1rem; color: #667eea; }
        .risk-summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
        .risk-summary-item strong { display: block; color: #666; font-size: 0.85rem; }
        .risk-summary-item span { font-size: 1.3rem; font-weight: bold; color: #333; }
        .strategy-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin: 1.5rem 0; }
        .strategy-card { border: 2px solid #ddd; border-radius: 10px; padding: 1.5rem; cursor: pointer; transition: all 0.3s; }
        .strategy-card:hover { border-color: #667eea; background: #f8f9fa; }
        .strategy-card.selected { border-color: #667eea; background: #667eea; color: white; }
        .strategy-card h4 { margin-bottom: 0.5rem; }
        .strategy-card p { font-size: 0.9rem; opacity: 0.8; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-weight: 600; margin-bottom: 0.5rem; color: #333; font-size: 0.95rem; }
        .form-group select, .form-group input, .form-group textarea { padding: 0.8rem; border: 1px solid #ddd; border-radius: 5px; font-size: 0.95rem; font-family: inherit; }
        .form-group select:focus, .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #667eea; }
        .control-list { max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 5px; padding: 1rem; }
        .control-item { padding: 1rem; margin-bottom: 0.8rem; border: 2px solid #e9ecef; border-radius: 5px; cursor: pointer; transition: all 0.3s; }
        .control-item:hover { border-color: #667eea; background: #f8f9fa; }
        .control-item.selected { border-color: #667eea; background: #667eea15; }
        .control-item h4 { margin-bottom: 0.5rem; color: #333; }
        .control-item .cost-info { font-size: 0.85rem; color: #666; margin-top: 0.5rem; }
        .cost-benefit-display { background: #fff3cd; padding: 1.5rem; border-radius: 10px; margin-top: 1.5rem; border-left: 5px solid #ffc107; }
        .cost-benefit-display h3 { color: #856404; margin-bottom: 1rem; }
        .cost-benefit-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
        .cost-benefit-item { background: white; padding: 1rem; border-radius: 5px; }
        .cost-benefit-item strong { display: block; font-size: 0.85rem; color: #666; }
        .cost-benefit-item .value { font-size: 1.5rem; font-weight: bold; color: #333; margin-top: 0.5rem; }
        .btn { padding: 0.8rem 1.5rem; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1rem; text-decoration: none; display: inline-block; transition: background 0.3s; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        th { background: #f8f9fa; padding: 0.8rem; text-align: left; font-weight: 600; border-bottom: 2px solid #dee2e6; }
        td { padding: 0.8rem; border-bottom: 1px solid #e9ecef; }
        tr:hover { background: #f8f9fa; }
        .risk-badge { display: inline-block; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.85rem; font-weight: 500; }
        .risk-極低 { background: #d4edda; color: #155724; }
        .risk-低 { background: #d1ecf1; color: #0c5460; }
        .risk-中 { background: #fff3cd; color: #856404; }
        .risk-高 { background: #f8d7da; color: #721c24; }
        .risk-極高 { background: #dc3545; color: white; }
        .status-badge { display: inline-block; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.85rem; font-weight: 500; }
        .status-規劃中 { background: #fff3cd; color: #856404; }
        .status-執行中 { background: #cfe2ff; color: #084298; }
        .status-已完成 { background: #d4edda; color: #155724; }
        .info-box { background: #e7f3ff; border-left: 4px solid #2196f3; padding: 1rem; margin-bottom: 1.5rem; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
            <a href="settings.php">系統設定</a>
        </nav>
    </div>
    
    <div class="container">
        <?php if (isset($message)): ?>
        <div class="alert">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab(0)" id="tab-btn-0">🎯 新增處理計畫</button>
            <button class="tab" onclick="switchTab(1)" id="tab-btn-1">📋 處理計畫列表</button>
        </div>
        
        <!-- Tab 1: 新增/編輯處理計畫 -->
        <div class="tab-content active" id="tab-content-0">
            <form method="POST" id="treatmentForm">
                <input type="hidden" name="action" value="<?php echo $edit_treatment ? 'update_treatment' : 'save_treatment'; ?>">
                <?php if ($edit_treatment): ?>
                <input type="hidden" name="treatment_id" value="<?php echo $edit_treatment['id']; ?>">
                <?php endif; ?>
                
                <div class="card">
                    <h2><?php echo $edit_treatment ? '✏️ 編輯處理計畫' : '選擇要處理的風險'; ?></h2>
                    <div class="form-group">
                        <label>選擇風險評估 *</label>
                        <select name="risk_assessment_id" id="risk_select" required onchange="loadRiskInfo()" <?php echo $edit_treatment ? 'disabled' : ''; ?>>
                            <option value="">請選擇風險</option>
                            <?php foreach ($pending_risks as $risk): ?>
                            <option value="<?php echo $risk['id']; ?>" <?php echo ($selected_risk && $selected_risk['id'] == $risk['id']) || ($edit_treatment && $edit_treatment['risk_assessment_id'] == $risk['id']) ? 'selected' : ''; ?> data-score="<?php echo $risk['risk_score']; ?>" data-level="<?php echo $risk['risk_level']; ?>" data-asset="<?php echo htmlspecialchars($risk['asset_name']); ?>" data-threat="<?php echo htmlspecialchars($risk['threat_name']); ?>">
                                <?php echo $risk['assessment_code']; ?> - <?php echo $risk['asset_name']; ?> (風險: <?php echo $risk['risk_level']; ?>, 分數: <?php echo $risk['risk_score']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($edit_treatment): ?>
                        <input type="hidden" name="risk_assessment_id" value="<?php echo $edit_treatment['risk_assessment_id']; ?>">
                        <?php endif; ?>
                    </div>
                    
                    <div id="riskSummary" style="display: <?php echo ($selected_risk || $edit_treatment) ? 'block' : 'none'; ?>;">
                        <div class="risk-summary">
                            <h3>風險資訊摘要</h3>
                            <div class="risk-summary-grid">
                                <div class="risk-summary-item">
                                    <strong>資產名稱</strong>
                                    <span id="summary_asset"><?php echo $selected_risk ? htmlspecialchars($selected_risk['asset_name']) : ($edit_treatment ? htmlspecialchars($edit_treatment['asset_name']) : '-'); ?></span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>威脅類型</strong>
                                    <span id="summary_threat"><?php echo $selected_risk ? htmlspecialchars($selected_risk['threat_name']) : ($edit_treatment ? htmlspecialchars($edit_treatment['threat_name']) : '-'); ?></span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>風險分數</strong>
                                    <span id="summary_score"><?php echo $selected_risk ? $selected_risk['risk_score'] : ($edit_treatment ? $edit_treatment['risk_score'] : '-'); ?></span>
                                </div>
                                <div class="risk-summary-item">
                                    <strong>風險等級</strong>
                                    <span id="summary_level"><?php echo $selected_risk ? $selected_risk['risk_level'] : ($edit_treatment ? 'N/A' : '-'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>選擇處理策略</h2>
                    <div class="info-box"><strong>說明：</strong>根據風險等級和組織風險偏好，選擇最適當的處理策略。系統將自動計算成本效益。</div>
                    <input type="hidden" name="treatment_strategy" id="strategy_value" value="<?php echo $edit_treatment ? $edit_treatment['treatment_strategy'] : ''; ?>">
                    <div class="strategy-grid">
                        <div class="strategy-card <?php echo ($edit_treatment && $edit_treatment['treatment_strategy'] == '降低') ? 'selected' : ''; ?>" onclick="selectStrategy('降低')"><h4>🛡️ 降低風險</h4><p>實施控制措施降低風險至可接受範圍</p></div>
                        <div class="strategy-card <?php echo ($edit_treatment && $edit_treatment['treatment_strategy'] == '轉移') ? 'selected' : ''; ?>" onclick="selectStrategy('轉移')"><h4>🔄 轉移風險</h4><p>透過保險或外包將風險轉移給第三方</p></div>
                        <div class="strategy-card <?php echo ($edit_treatment && $edit_treatment['treatment_strategy'] == '避免') ? 'selected' : ''; ?>" onclick="selectStrategy('避免')"><h4>🚫 避免風險</h4><p>停止或不進行會產生風險的活動</p></div>
                        <div class="strategy-card <?php echo ($edit_treatment && $edit_treatment['treatment_strategy'] == '接受') ? 'selected' : ''; ?>" onclick="selectStrategy('接受')"><h4>✅ 接受風險</h4><p>當風險等級低或處理成本過高時接受風險</p></div>
                    </div>
                </div>
                
                <div class="card" id="controlSection" style="display: <?php echo ($edit_treatment && $edit_treatment['treatment_strategy'] == '降低') ? 'block' : 'none'; ?>;">
                    <h2>選擇控制措施</h2>
                    <div class="info-box"><strong>說明：</strong>選擇一個或多個控制措施來降低風險。系統會顯示每個措施的成本和效益。</div>
                    <input type="hidden" name="control_measure_id" id="control_value" value="<?php echo $edit_treatment ? $edit_treatment['control_measure_id'] : ''; ?>">
                    <div class="control-list">
                        <?php foreach ($control_measures as $control): ?>
                        <div class="control-item <?php echo ($edit_treatment && $edit_treatment['control_measure_id'] == $control['id']) ? 'selected' : ''; ?>" onclick="selectControl(<?php echo $control['id']; ?>, <?php echo $control['implementation_cost']; ?>, <?php echo $control['annual_cost']; ?>, <?php echo $control['effectiveness']; ?>)">
                            <h4><?php echo htmlspecialchars($control['control_name']); ?></h4>
                            <p style="font-size: 0.9rem; color: #666; margin: 0.5rem 0;"><?php echo htmlspecialchars($control['control_desc']); ?></p>
                            <div class="cost-info">類型: <?php echo $control['control_type']; ?> | 有效性: <?php echo $control['effectiveness']; ?>/5 | 實施成本: $<?php echo number_format($control['implementation_cost']); ?> | 年度成本: $<?php echo number_format($control['annual_cost']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div id="costBenefitDisplay" style="display: none;" class="cost-benefit-display">
                        <h3>💰 成本效益分析</h3>
                        <div class="cost-benefit-grid">
                            <div class="cost-benefit-item"><strong>風險價值估算</strong><div class="value" id="risk_value">$0</div></div>
                            <div class="cost-benefit-item"><strong>控制措施總成本(3年)</strong><div class="value" id="control_cost">$0</div></div>
                            <div class="cost-benefit-item"><strong>成本效益比</strong><div class="value" id="cost_benefit_ratio">0</div></div>
                        </div>
                        <p style="margin-top: 1rem; color: #856404;"><strong>說明：</strong>成本效益比 = (風險降低價值 - 實施成本) / 實施成本。比值越高表示投資回報越好。建議選擇比值 > 1 的控制措施。</p>
                    </div>
                </div>
                
                <div class="card">
                    <h2>殘餘風險評估</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>殘餘風險等級 *</label>
                            <select name="residual_risk_level" required>
                                <option value="">請選擇</option>
                                <?php foreach(['極低', '低', '中', '高', '極高'] as $level): ?>
                                <option value="<?php echo $level; ?>" <?php echo ($edit_treatment && $edit_treatment['residual_risk_level'] == $level) ? 'selected' : ''; ?>><?php echo $level; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>殘餘風險分數 *</label>
                            <input type="number" name="residual_risk_score" step="0.01" required value="<?php echo $edit_treatment ? $edit_treatment['residual_risk_score'] : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>執行優先順序 *</label>
                            <select name="implementation_priority" required>
                                <option value="">請選擇</option>
                                <?php foreach(['高', '中', '低'] as $priority): ?>
                                <option value="<?php echo $priority; ?>" <?php echo ($edit_treatment && $edit_treatment['implementation_priority'] == $priority) ? 'selected' : ''; ?>><?php echo $priority; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>負責人 *</label>
                            <input type="text" name="responsible_person" required value="<?php echo $edit_treatment ? htmlspecialchars($edit_treatment['responsible_person']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>目標完成日期</label>
                            <input type="date" name="target_date" value="<?php echo $edit_treatment ? $edit_treatment['target_date'] : ''; ?>">
                        </div>
                        <?php if ($edit_treatment): ?>
                        <div class="form-group">
                            <label>執行狀態 *</label>
                            <select name="status" required>
                                <option value="規劃中" <?php echo ($edit_treatment['status'] == '規劃中') ? 'selected' : ''; ?>>規劃中</option>
                                <option value="執行中" <?php echo ($edit_treatment['status'] == '執行中') ? 'selected' : ''; ?>>執行中</option>
                                <option value="已完成" <?php echo ($edit_treatment['status'] == '已完成') ? 'selected' : ''; ?>>已完成</option>
                                <option value="已取消" <?php echo ($edit_treatment['status'] == '已取消') ? 'selected' : ''; ?>>已取消</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="margin-top: 1rem;">
                        <label>備註</label>
                        <textarea name="notes" rows="3"><?php echo $edit_treatment ? htmlspecialchars($edit_treatment['notes']) : ''; ?></textarea>
                    </div>
                    <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn">💾 <?php echo $edit_treatment ? '更新' : '建立'; ?>處理計畫</button>
                        <?php if ($edit_treatment): ?>
                        <a href="risk_treatment.php" class="btn btn-secondary">取消編輯</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Part 2 將包含：Tab 2 內容 + JavaScript -->
         <!-- Tab 2: 處理計畫列表 -->
        <div class="tab-content" id="tab-content-1">
            <div class="card">
                <h2>📋 風險處理計畫列表</h2>
                <table>
                    <thead>
                        <tr>
                            <th>評估編號</th>
                            <th>資產</th>
                            <th>原風險</th>
                            <th>處理策略</th>
                            <th>控制措施</th>
                            <th>殘餘風險</th>
                            <th>成本效益比</th>
                            <th>狀態</th>
                            <th>負責人</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($treatments)): ?>
                        <tr>
                            <td colspan="10" style="text-align: center; padding: 2rem; color: #666;">目前沒有風險處理計畫</td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($treatments as $treatment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($treatment['assessment_code']); ?></td>
                            <td><?php echo htmlspecialchars($treatment['asset_name']); ?></td>
                            <td>
                                <span class="risk-badge risk-<?php echo $treatment['risk_level']; ?>">
                                    <?php echo $treatment['risk_level']; ?> (<?php echo $treatment['risk_score']; ?>)
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($treatment['treatment_strategy']); ?></td>
                            <td><?php echo $treatment['control_name'] ? htmlspecialchars($treatment['control_name']) : '-'; ?></td>
                            <td>
                                <span class="risk-badge risk-<?php echo $treatment['residual_risk_level']; ?>">
                                    <?php echo $treatment['residual_risk_level']; ?>
                                </span>
                            </td>
                            <td><strong><?php echo $treatment['cost_benefit_ratio'] ? number_format($treatment['cost_benefit_ratio'], 2) : '-'; ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo $treatment['status']; ?>">
                                    <?php echo htmlspecialchars($treatment['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($treatment['responsible_person']); ?></td>
                            <td>
                                <div style="display: flex; gap: 0.3rem; flex-wrap: wrap;">
                                    <a href="?edit_id=<?php echo $treatment['id']; ?>" class="btn" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">✏️ 編輯</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('確定要刪除此處理計畫嗎？');">
                                        <input type="hidden" name="action" value="delete_treatment">
                                        <input type="hidden" name="treatment_id" value="<?php echo $treatment['id']; ?>">
                                        <input type="hidden" name="risk_assessment_id" value="<?php echo $treatment['risk_assessment_id']; ?>">
                                        <button type="submit" class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;">🗑️ 刪除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function switchTab(index) {
            // 移除所有 active 類別
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            // 加入 active 類別到選中的 tab
            document.getElementById('tab-btn-' + index).classList.add('active');
            document.getElementById('tab-content-' + index).classList.add('active');
        }
        
        function loadRiskInfo() {
            const select = document.getElementById('risk_select');
            if (!select || !select.value) return;
            
            const option = select.options[select.selectedIndex];
            document.getElementById('riskSummary').style.display = 'block';
            document.getElementById('summary_asset').textContent = option.dataset.asset || '-';
            document.getElementById('summary_threat').textContent = option.dataset.threat || '-';
            document.getElementById('summary_score').textContent = option.dataset.score || '-';
            document.getElementById('summary_level').textContent = option.dataset.level || '-';
            window.currentRiskScore = parseFloat(option.dataset.score || 0);
        }
        
        function selectStrategy(strategy) {
            document.getElementById('strategy_value').value = strategy;
            document.querySelectorAll('.strategy-card').forEach(card => card.classList.remove('selected'));
            event.currentTarget.classList.add('selected');
            
            if (strategy === '降低') {
                document.getElementById('controlSection').style.display = 'block';
            } else {
                document.getElementById('controlSection').style.display = 'none';
                document.getElementById('control_value').value = '';
            }
        }
        
        function selectControl(id, implCost, annualCost, effectiveness) {
            document.getElementById('control_value').value = id;
            document.querySelectorAll('.control-item').forEach(item => item.classList.remove('selected'));
            event.currentTarget.classList.add('selected');
            calculateCostBenefit(implCost, annualCost, effectiveness);
        }
        
        function calculateCostBenefit(implCost, annualCost, effectiveness) {
            if (!window.currentRiskScore) return;
            
            const riskValue = window.currentRiskScore * 100000;
            const totalCost = implCost + (annualCost * 3);
            const costBenefitRatio = totalCost > 0 ? (riskValue - totalCost) / totalCost : 0;
            
            document.getElementById('costBenefitDisplay').style.display = 'block';
            document.getElementById('risk_value').textContent = '$' + riskValue.toLocaleString();
            document.getElementById('control_cost').textContent = '$' + totalCost.toLocaleString();
            document.getElementById('cost_benefit_ratio').textContent = costBenefitRatio.toFixed(2);
            
            const ratioElement = document.getElementById('cost_benefit_ratio');
            if (costBenefitRatio > 5) {
                ratioElement.style.color = '#28a745';
            } else if (costBenefitRatio > 1) {
                ratioElement.style.color = '#ffc107';
            } else {
                ratioElement.style.color = '#dc3545';
            }
        }
        
        // 頁面載入初始化
        window.onload = function() {
            <?php if ($edit_treatment): ?>
            // 編輯模式：切換到表單 Tab
            switchTab(0);
            loadRiskInfo();
            if (document.getElementById('strategy_value').value === '降低') {
                document.getElementById('controlSection').style.display = 'block';
            }
            window.currentRiskScore = <?php echo $edit_treatment['risk_score']; ?>;
            <?php elseif ($selected_risk): ?>
            // 新增模式：載入選中的風險
            switchTab(0);
            loadRiskInfo();
            <?php endif; ?>
        };
    </script>
</body>
</html>