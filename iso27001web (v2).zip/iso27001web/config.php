<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 資料庫連線設定檔及通用輔助函數
 */

// **********************************
// 1. 資料庫連線參數
// **********************************
define('DB_HOST', 'localhost');
define('DB_NAME', 'iso27001_risk_system');
define('DB_USER', 'root'); // 請根據您的 XAMPP/WAMP 設定修改
define('DB_PASS', '');     // 請根據您的 XAMPP/WAMP 設定修改
define('DB_CHARSET', 'utf8mb4');

// **********************************
// 2. 建立 PDO 連線函數
// **********************************
/**
 * 建立並返回一個 PDO 資料庫連線實例
 * @return PDO
 */
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,        // 啟用例外錯誤模式
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,   // 預設以關聯陣列取得結果
            PDO::ATTR_EMULATE_PREPARES => false,                // 禁用模擬預處理
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        // 連線失敗時終止程式並顯示錯誤
        die("資料庫連線失敗: " . $e->getMessage());
    }
}

// **********************************
// 3. 資料庫通用操作輔助函數
// **********************************

/**
 * 執行任何 SQL 查詢 (INSERT, UPDATE, DELETE, SELECT)
 * @param string $sql 帶有 ? 佔位符的 SQL 語句
 * @param array $params 綁定參數
 * @return PDOStatement
 */
function executeQuery($sql, $params = []) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/**
 * 取得單一記錄 (用於 SELECT 查詢)
 * @param string $sql SQL 語句
 * @param array $params 綁定參數
 * @return array|false 關聯陣列或 false
 */
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}

/**
 * 取得多筆記錄 (用於 SELECT 查詢)
 * @param string $sql SQL 語句
 * @param array $params 綁定參數
 * @return array 關聯陣列數組
 */
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

/**
 * 插入資料並返回新插入記錄的 ID
 * @param string $sql INSERT SQL 語句
 * @param array $params 綁定參數
 * @return string 新記錄的 ID
 */
function insertAndGetId($sql, $params = []) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $pdo->lastInsertId();
}

// **********************************
// 4. 系統工具函數
// **********************************

/**
 * 取得系統設定表中的單一設定值
 * @param string $key 設定鍵
 * @return string|null 設定值或 null
 */
function getSystemConfig($key) {
    // 此處呼叫 fetchOne，因為它已經定義在上方
    $result = fetchOne("SELECT config_value FROM system_config WHERE config_key = ?", [$key]);
    return $result ? $result['config_value'] : null;
}

/**
 * 根據可能性和影響值計算風險分數和等級 (查表)
 * @param int $likelihood 可能性值 (1-5)
 * @param int $impact 影響值 (1-5)
 * @return array|false 包含 risk_score, risk_level, color_code 的陣列或 false
 */
function calculateRiskScore($likelihood, $impact) {
    // 此處呼叫 fetchOne，因為它已經定義在上方
    $matrix = fetchOne(
        "SELECT risk_score, risk_level, color_code FROM risk_matrix WHERE likelihood_value = ? AND impact_value = ?",
        [$likelihood, $impact]
    );
    return $matrix;
}