<?php
/**
 * ISO 27001:2022 風險評估與管理系統
 * 報表與分析界面
 */
require_once 'config.php';

// 取得統計數據
$stats = [
    'total_assets' => fetchOne("SELECT COUNT(*) as count FROM assets")['count'],
    'total_risks' => fetchOne("SELECT COUNT(*) as count FROM risk_assessments")['count'],
    'high_risks' => fetchOne("SELECT COUNT(*) as count FROM risk_assessments WHERE risk_level IN ('高', '極高')")['count'],
    'total_treatments' => fetchOne("SELECT COUNT(*) as count FROM risk_treatments")['count'],
    'completed_treatments' => fetchOne("SELECT COUNT(*) as count FROM risk_treatments WHERE status = '已完成'")['count'],
];

// 風險等級分布
$risk_distribution = fetchAll("
    SELECT risk_level, COUNT(*) as count 
    FROM risk_assessments 
    GROUP BY risk_level 
    ORDER BY FIELD(risk_level, '極低', '低', '中', '高', '極高')
");

// 依資產類別的風險統計
$risk_by_category = fetchAll("
    SELECT ac.category_name, COUNT(ra.id) as risk_count,
           SUM(CASE WHEN ra.risk_level IN ('高', '極高') THEN 1 ELSE 0 END) as high_risk_count
    FROM asset_categories ac
    LEFT JOIN assets a ON ac.id = a.category_id
    LEFT JOIN risk_assessments ra ON a.id = ra.asset_id
    GROUP BY ac.id, ac.category_name
    ORDER BY risk_count DESC
");

// 威脅類型統計
$threat_stats = fetchAll("
    SELECT t.threat_name, COUNT(ra.id) as count,
           AVG(ra.risk_score) as avg_score
    FROM threat_types t
    LEFT JOIN risk_assessments ra ON t.id = ra.threat_id
    GROUP BY t.id, t.threat_name
    HAVING count > 0
    ORDER BY count DESC
    LIMIT 10
");

// 控制措施效益分析
$control_effectiveness = fetchAll("
    SELECT cm.control_name, cm.control_type,
           COUNT(rt.id) as usage_count,
           AVG(rt.cost_benefit_ratio) as avg_benefit,
           cm.implementation_cost, cm.annual_cost
    FROM control_measures cm
    LEFT JOIN risk_treatments rt ON cm.id = rt.control_measure_id
    WHERE cm.is_active = 1
    GROUP BY cm.id
    HAVING usage_count > 0
    ORDER BY avg_benefit DESC
    LIMIT 10
");

// 高風險資產清單
$high_risk_assets = fetchAll("
    SELECT a.asset_code, a.asset_name, ac.category_name,
           COUNT(ra.id) as risk_count,
           SUM(CASE WHEN ra.risk_level = '極高' THEN 1 ELSE 0 END) as critical_count,
           SUM(CASE WHEN ra.risk_level = '高' THEN 1 ELSE 0 END) as high_count,
           MAX(ra.risk_score) as max_risk_score
    FROM assets a
    LEFT JOIN asset_categories ac ON a.category_id = ac.id
    LEFT JOIN risk_assessments ra ON a.id = ra.asset_id
    WHERE ra.risk_level IN ('高', '極高')
    GROUP BY a.id
    ORDER BY max_risk_score DESC, risk_count DESC
    LIMIT 15
");

// 風險處理進度
$treatment_progress = fetchAll("
    SELECT status, COUNT(*) as count
    FROM risk_treatments
    GROUP BY status
");

// 月度風險趨勢
$monthly_trend = fetchAll("
    SELECT DATE_FORMAT(assessment_date, '%Y-%m') as month,
           COUNT(*) as total_risks,
           SUM(CASE WHEN risk_level IN ('高', '極高') THEN 1 ELSE 0 END) as high_risks
    FROM risk_assessments
    WHERE assessment_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY month
    ORDER BY month
");

// 處理空陣列情況
if (empty($risk_distribution)) {
    $risk_distribution = [['risk_level' => '無資料', 'count' => 0]];
}
if (empty($monthly_trend)) {
    $monthly_trend = [['month' => date('Y-m'), 'total_risks' => 0, 'high_risks' => 0]];
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>報表分析 - <?php echo $page_title; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft JhengHei', Arial, sans-serif; background: #f5f7fa; }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .navbar nav a { color: white; text-decoration: none; margin-right: 1.5rem; font-weight: 500; }
        
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            text-align: center;
        }
        .stat-card .icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
            margin: 0.5rem 0;
        }
        .stat-card .label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .report-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .card.full-width {
            grid-column: 1 / -1;
        }
        
        .card h2 {
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 0.5rem;
        }
        
        .chart-container {
            padding: 1rem 0;
        }
        
        .bar-chart {
            margin-bottom: 1rem;
        }
        
        .bar-chart-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.8rem;
        }
        
        .bar-label {
            width: 150px;
            font-size: 0.9rem;
            color: #666;
            padding-right: 1rem;
        }
        
        .bar-track {
            flex: 1;
            height: 30px;
            background: #f0f0f0;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        
        .bar-fill {
            height: 100%;
            display: flex;
            align-items: center;
            padding-left: 10px;
            color: white;
            font-weight: bold;
            font-size: 0.9rem;
            transition: width 0.5s ease;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        th {
            background: #f8f9fa;
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 0.8rem;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .progress-ring {
            width: 120px;
            height: 120px;
            margin: 0 auto;
        }
        
        .progress-circle {
            fill: none;
            stroke-width: 10;
            stroke-linecap: round;
            transform: rotate(-90deg);
            transform-origin: center;
        }
        
        .progress-bg {
            stroke: #e9ecef;
        }
        
        .progress-fg {
            stroke: #667eea;
            transition: stroke-dashoffset 0.5s ease;
        }
        
        .progress-text {
            text-align: center;
            margin-top: 1rem;
            font-size: 1.5rem;
            font-weight: bold;
            color: #667eea;
        }
        
        .trend-line {
            display: flex;
            align-items: flex-end;
            justify-content: space-around;
            height: 200px;
            border-bottom: 2px solid #dee2e6;
            padding: 1rem 0;
        }
        
        .trend-bar {
            flex: 1;
            margin: 0 0.3rem;
            background: linear-gradient(to top, #667eea, #764ba2);
            border-radius: 5px 5px 0 0;
            position: relative;
            transition: height 0.5s ease;
            min-height: 10px;
        }
        
        .trend-label {
            position: absolute;
            bottom: -25px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 0.75rem;
            color: #666;
        }
        
        .trend-value {
            position: absolute;
            top: -20px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 0.8rem;
            font-weight: bold;
            color: #333;
        }
        
        .btn {
            padding: 0.8rem 1.5rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        .export-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        @media print {
            .navbar, .export-buttons { display: none; }
            .card { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>🛡️ ISO 27001:2022 風險評估與管理系統</h1>
        <nav>
            <a href="index.php">儀表板</a>
            <a href="assets.php">資產管理</a>
            <a href="risk_assessment.php">風險評估</a>
            <a href="risk_treatment.php">風險處理</a>
            <a href="reports.php">報表分析</a>
        </nav>
    </div>
    
    <div class="container">
        <div class="export-buttons">
            <button class="btn" onclick="window.print()">🖨️ 列印報表</button>
            <a href="export_excel.php" class="btn">📊 匯出Excel</a>
        </div>
        
        <!-- 統計卡片 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon">📦</div>
                <div class="value"><?php echo $stats['total_assets']; ?></div>
                <div class="label">總資產數</div>
            </div>
            <div class="stat-card">
                <div class="icon">⚠️</div>
                <div class="value"><?php echo $stats['total_risks']; ?></div>
                <div class="label">風險評估數</div>
            </div>
            <div class="stat-card">
                <div class="icon">🔴</div>
                <div class="value"><?php echo $stats['high_risks']; ?></div>
                <div class="label">高風險項目</div>
            </div>
            <div class="stat-card">
                <div class="icon">🛡️</div>
                <div class="value"><?php echo $stats['total_treatments']; ?></div>
                <div class="label">處理計畫數</div>
            </div>
            <div class="stat-card">
                <div class="icon">✅</div>
                <div class="value"><?php echo $stats['completed_treatments']; ?></div>
                <div class="label">已完成處理</div>
            </div>
        </div>
        
        <!-- 報表網格 -->
        <div class="report-grid">
            <!-- 風險等級分布 -->
            <div class="card">
                <h2>📊 風險等級分布</h2>
                <div class="chart-container">
                    <?php
                    $colors = ['極低' => '#28a745', '低' => '#17a2b8', '中' => '#ffc107', '高' => '#dc3545', '極高' => '#6c0000'];
                    $max_count = max(array_column($risk_distribution, 'count'));
                    foreach ($risk_distribution as $item):
                        $percentage = $max_count > 0 ? ($item['count'] / $max_count * 100) : 0;
                    ?>
                    <div class="bar-chart-item">
                        <div class="bar-label"><?php echo $item['risk_level']; ?></div>
                        <div class="bar-track">
                            <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: <?php echo $colors[$item['risk_level']]; ?>;">
                                <?php echo $item['count']; ?> 項
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- 風險處理進度 -->
            <div class="card">
                <h2>🎯 風險處理進度</h2>
                <div class="chart-container">
                    <?php
                    $total_treatments = array_sum(array_column($treatment_progress, 'count'));
                    $completed = 0;
                    foreach ($treatment_progress as $tp) {
                        if ($tp['status'] == '已完成') $completed = $tp['count'];
                    }
                    $completion_rate = $total_treatments > 0 ? ($completed / $total_treatments * 100) : 0;
                    $circumference = 2 * 3.14159 * 50;
                    $offset = $circumference - ($completion_rate / 100 * $circumference);
                    ?>
                    <svg class="progress-ring" viewBox="0 0 120 120">
                        <circle class="progress-circle progress-bg" cx="60" cy="60" r="50"></circle>
                        <circle class="progress-circle progress-fg" cx="60" cy="60" r="50"
                                stroke-dasharray="<?php echo $circumference; ?>"
                                stroke-dashoffset="<?php echo $offset; ?>"></circle>
                    </svg>
                    <div class="progress-text"><?php echo round($completion_rate); ?>%</div>
                    <div style="text-align: center; margin-top: 1rem; color: #666;">
                        <?php echo $completed; ?> / <?php echo $total_treatments; ?> 已完成
                    </div>
                    
                    <div style="margin-top: 2rem;">
                        <?php foreach ($treatment_progress as $tp): ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span><?php echo $tp['status']; ?></span>
                            <strong><?php echo $tp['count']; ?> 項</strong>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <!-- 依資產類別的風險統計 -->
            <div class="card">
                <h2>📁 各類別資產風險統計</h2>
                <table>
                    <thead>
                        <tr>
                            <th>資產類別</th>
                            <th>風險總數</th>
                            <th>高風險數</th>
                            <th>風險比例</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($risk_by_category as $cat): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($cat['category_name']); ?></td>
                            <td><?php echo $cat['risk_count']; ?></td>
                            <td><strong style="color: #dc3545;"><?php echo $cat['high_risk_count']; ?></strong></td>
                            <td>
                                <?php 
                                $ratio = $cat['risk_count'] > 0 ? ($cat['high_risk_count'] / $cat['risk_count'] * 100) : 0;
                                echo round($ratio, 1) . '%';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Top 10 威脅類型 -->
            <div class="card">
                <h2>🎯 Top 10 威脅類型</h2>
                <table>
                    <thead>
                        <tr>
                            <th>威脅名稱</th>
                            <th>發生次數</th>
                            <th>平均風險分數</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($threat_stats as $threat): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($threat['threat_name']); ?></td>
                            <td><?php echo $threat['count']; ?></td>
                            <td><strong><?php echo round($threat['avg_score'], 2); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- 高風險資產清單 -->
            <div class="card full-width">
                <h2>🔴 高風險資產清單</h2>
                <table>
                    <thead>
                        <tr>
                            <th>資產編號</th>
                            <th>資產名稱</th>
                            <th>類別</th>
                            <th>風險總數</th>
                            <th>極高風險</th>
                            <th>高風險</th>
                            <th>最高風險分數</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($high_risk_assets as $asset): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($asset['asset_code']); ?></strong></td>
                            <td><?php echo htmlspecialchars($asset['asset_name']); ?></td>
                            <td><?php echo htmlspecialchars($asset['category_name']); ?></td>
                            <td><?php echo $asset['risk_count']; ?></td>
                            <td style="color: #6c0000; font-weight: bold;"><?php echo $asset['critical_count']; ?></td>
                            <td style="color: #dc3545; font-weight: bold;"><?php echo $asset['high_count']; ?></td>
                            <td><strong><?php echo $asset['max_risk_score']; ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- 控制措施效益分析 -->
            <div class="card full-width">
                <h2>💰 控制措施成本效益分析</h2>
                <table>
                    <thead>
                        <tr>
                            <th>控制措施名稱</th>
                            <th>類型</th>
                            <th>使用次數</th>
                            <th>實施成本</th>
                            <th>年度成本</th>
                            <th>平均成本效益比</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($control_effectiveness as $control): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($control['control_name']); ?></td>
                            <td><?php echo $control['control_type']; ?></td>
                            <td><?php echo $control['usage_count']; ?></td>
                            <td>$<?php echo number_format($control['implementation_cost']); ?></td>
                            <td>$<?php echo number_format($control['annual_cost']); ?></td>
                            <td>
                                <strong style="color: <?php echo $control['avg_benefit'] > 1 ? '#28a745' : '#dc3545'; ?>;">
                                    <?php echo number_format($control['avg_benefit'], 2); ?>
                                </strong>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- 月度風險趨勢 -->
            <div class="card full-width">
                <h2>📈 月度風險趨勢 (過去12個月)</h2>
                <div class="trend-line">
                    <?php
                    $max_risks = max(array_column($monthly_trend, 'total_risks'));
                    foreach ($monthly_trend as $trend):
                        $height = $max_risks > 0 ? ($trend['total_risks'] / $max_risks * 100) : 10;
                    ?>
                    <div class="trend-bar" style="height: <?php echo $height; ?>%;">
                        <div class="trend-value"><?php echo $trend['total_risks']; ?></div>
                        <div class="trend-label"><?php echo date('Y/m', strtotime($trend['month'] . '-01')); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top: 3rem; text-align: center; color: #666;">
                    <span style="display: inline-block; margin: 0 1rem;">
                        <span style="display: inline-block; width: 20px; height: 20px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 3px; vertical-align: middle;"></span>
                        總風險數
                    </span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>